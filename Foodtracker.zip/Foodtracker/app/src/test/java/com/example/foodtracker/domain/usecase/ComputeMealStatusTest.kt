import org.junit.jupiter.api.Test
import org.junit.jupiter.api.Assertions.assertEquals
import java.time.LocalDate

class ComputeMealStatusTest {
    @Test
    fun `meal becomes expired after shelf life`() {
        val meal = Meal(
            id = 1L,
            name = "Pasta",
            prepDate = LocalDate.now().minusDays(3),
            storage = StorageLocation.FRIDGE,
            totalPortions = 2,
            shelfLifeDays = 2
        )
        val status = ComputeMealStatus()(meal)
        assertEquals(MealStatus.EXPIRED, status)
    }
}
