package com.example.foodtracker.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "food_items")
data class FoodItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val quantity: Int,
    val expirationDate: Long, // Timestamp
    val price: Double
) {
    companion object {
        private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        
        fun formatDate(timestamp: Long): String {
            return dateFormat.format(Date(timestamp))
        }
    }
    
    fun getFormattedExpirationDate(): String {
        return formatDate(expirationDate)
    }
}
