package com.example.foodtracker.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import com.example.foodtracker.database.FoodDatabase
import com.example.foodtracker.model.FoodItem
import com.example.foodtracker.repository.FoodRepository
import kotlinx.coroutines.launch

class FoodViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FoodRepository
    val allFoodItems: LiveData<List<FoodItem>>
    
    init {
        val foodDao = FoodDatabase.getDatabase(application).foodDao()
        repository = FoodRepository(foodDao)
        allFoodItems = repository.allFoodItems
    }
    
    fun insert(foodItem: FoodItem) = viewModelScope.launch {
        repository.insert(foodItem)
    }
    
    fun delete(foodItem: FoodItem) = viewModelScope.launch {
        repository.delete(foodItem)
    }
    
    fun getCombinedFoodItems(): LiveData<List<FoodItem>> {
        return repository.getCombinedFoodItems()
    }
}
