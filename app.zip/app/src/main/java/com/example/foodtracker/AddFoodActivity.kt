package com.example.foodtracker

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class AddFoodActivity : AppCompatActivity() {
    private var selectedDate: Long = System.currentTimeMillis()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_food)
        
        val expirationTextView = findViewById<TextView>(R.id.textViewExpirationDate)
        expirationTextView.text = FoodItem.formatDate(selectedDate)
        
        expirationTextView.setOnClickListener {
            showDatePicker()
        }
        
        val saveButton = findViewById<Button>(R.id.buttonSave)
        saveButton.setOnClickListener {
            saveFoodItem()
        }
    }
    
    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        
        val datePickerDialog = DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedCalendar = Calendar.getInstance()
                selectedCalendar.set(year, month, dayOfMonth)
                selectedDate = selectedCalendar.timeInMillis
                findViewById<TextView>(R.id.textViewExpirationDate).text = 
                    FoodItem.formatDate(selectedDate)
            },
            year, month, day
        )
        datePickerDialog.show()
    }
    
    private fun saveFoodItem() {
        val nameEditText = findViewById<EditText>(R.id.editTextName)
        val quantityEditText = findViewById<EditText>(R.id.editTextQuantity)
        val priceEditText = findViewById<EditText>(R.id.editTextPrice)
        
        val name = nameEditText.text.toString().trim()
        val quantity = quantityEditText.text.toString().toIntOrNull() ?: 1
        val price = priceEditText.text.toString().toDoubleOrNull() ?: 0.0
        
        if (name.isNotEmpty()) {
            val resultIntent = Intent().apply {
                putExtra("name", name)
                putExtra("quantity", quantity)
                putExtra("expirationDate", selectedDate)
                putExtra("price", price)
            }
            setResult(Activity.RESULT_OK, resultIntent)
            finish()
        }
    }
}
