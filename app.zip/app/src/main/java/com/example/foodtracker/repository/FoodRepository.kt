package com.example.foodtracker.repository

import androidx.lifecycle.LiveData
import com.example.foodtracker.database.FoodDao
import com.example.foodtracker.model.FoodItem

class FoodRepository(private val foodDao: FoodDao) {
    
    val allFoodItems: LiveData<List<FoodItem>> = foodDao.getAllFoodItems()
    
    suspend fun insert(foodItem: FoodItem) {
        foodDao.insert(foodItem)
    }
    
    suspend fun delete(foodItem: FoodItem) {
        foodDao.delete(foodItem)
    }
    
    suspend fun getFoodItemsByName(name: String): List<FoodItem> {
        return foodDao.getFoodItemsByName(name)
    }
    
    fun getCombinedFoodItems(): LiveData<List<FoodItem>> {
        return foodDao.getAllFoodItems()
    }
    
    suspend fun getAllFoodNames(): List<String> {
        return foodDao.getAllFoodNames()
    }
}
