package com.example.foodtracker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.foodtracker.adapter.FoodAdapter
import com.example.foodtracker.model.FoodItem
import com.example.foodtracker.viewmodel.FoodViewModel

class MainActivity : AppCompatActivity() {
    private lateinit var foodViewModel: FoodViewModel
    private lateinit var adapter: FoodAdapter
    private lateinit var addFoodLauncher: ActivityResultLauncher<Intent>
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        adapter = FoodAdapter { foodItem ->
            // Handle item click if needed
        }
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        
        foodViewModel = ViewModelProvider(this)[FoodViewModel::class.java]
        foodViewModel.allFoodItems.observe(this) { foodItems ->
            adapter.submitList(foodItems)
        }
        
        val addButton = findViewById<Button>(R.id.buttonAdd)
        addButton.setOnClickListener {
            val intent = Intent(this, AddFoodActivity::class.java)
            addFoodLauncher.launch(intent)
        }
        
        setupActivityResultLauncher()
    }
    
    private fun setupActivityResultLauncher() {
        addFoodLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val name = data?.getStringExtra("name") ?: return@registerForActivityResult
                val quantity = data.getIntExtra("quantity", 1)
                val expirationDate = data.getLongExtra("expirationDate", System.currentTimeMillis())
                val price = data.getDoubleExtra("price", 0.0)
                
                val foodItem = FoodItem(
                    name = name,
                    quantity = quantity,
                    expirationDate = expirationDate,
                    price = price
                )
                
                foodViewModel.insert(foodItem)
            }
        }
    }
}
