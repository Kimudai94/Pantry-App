package com.example.foodtracker.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.foodtracker.model.FoodItem

@Dao
interface FoodDao {
    @Query("SELECT * FROM food_items ORDER BY expirationDate ASC")
    fun getAllFoodItems(): LiveData<List<FoodItem>>
    
    @Query("SELECT * FROM food_items WHERE name = :name ORDER BY expirationDate ASC")
    fun getFoodItemsByName(name: String): List<FoodItem>
    
    @Insert
    suspend fun insert(foodItem: FoodItem)
    
    @Delete
    suspend fun delete(foodItem: FoodItem)
    
    @Query("DELETE FROM food_items")
    suspend fun deleteAll()
    
    @Query("SELECT DISTINCT name FROM food_items")
    suspend fun getAllFoodNames(): List<String>
}
