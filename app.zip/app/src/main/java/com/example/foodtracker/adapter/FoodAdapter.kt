package com.example.foodtracker.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.foodtracker.R
import com.example.foodtracker.model.FoodItem

class FoodAdapter(private val onItemClicked: (FoodItem) -> Unit) : 
    ListAdapter<FoodItem, FoodAdapter.FoodViewHolder>(FoodDiffCallback()) {
    
    class FoodViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val nameTextView: TextView = itemView.findViewById(R.id.textViewName)
        private val quantityTextView: TextView = itemView.findViewById(R.id.textViewQuantity)
        private val expirationTextView: TextView = itemView.findViewById(R.id.textViewExpiration)
        private val priceTextView: TextView = itemView.findViewById(R.id.textViewPrice)
        
        fun bind(foodItem: FoodItem, onItemClicked: (FoodItem) -> Unit) {
            nameTextView.text = foodItem.name
            quantityTextView.text = itemView.context.getString(R.string.quantity_format, foodItem.quantity)
            expirationTextView.text = foodItem.getFormattedExpirationDate()
            priceTextView.text = itemView.context.getString(R.string.price_format, foodItem.price)
            
            itemView.setOnClickListener { onItemClicked(foodItem) }
        }
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.food_item, parent, false)
        return FoodViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bind(getItem(position), onItemClicked)
    }
}

class FoodDiffCallback : DiffUtil.ItemCallback<FoodItem>() {
    override fun areItemsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean {
        return oldItem.id == newItem.id
    }
    
    override fun areContentsTheSame(oldItem: FoodItem, newItem: FoodItem): Boolean {
        return oldItem == newItem
    }
}
