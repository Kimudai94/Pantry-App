import androidx.lifecycle.ViewModel import androidx.lifecycle.viewModelScope import com.example.foodtracker.domain.model.Meal import com.example.foodtracker.domain.model.MealStatus import com.example.foodtracker.domain.usecase.ComputeMealStatus import kotlinx.coroutines.flow.MutableStateFlow import kotlinx.coroutines.flow.StateFlow import kotlinx.coroutines.flow.asStateFlow import kotlinx.coroutines.launch import java.time.LocalDate import java.time.temporal.ChronoUnit

class DashboardViewModel(
    private val loadMeals: suspend () -> List,
    private val computeMealStatus: ComputeMealStatus
) : ViewModel() {
    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow = _state.asStateFlow()
    fun refresh(today: LocalDate = LocalDate.now()) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            runCatching { loadMeals() }.onSuccess { meals ->
                val items = meals.map { meal ->
                    val status = computeMealStatus(meal, today)
                    val expiresAt = meal.prepDate.plusDays(meal.shelfLifeDays.toLong())
                    val expiresInDays = ChronoUnit.DAYS.between(today, expiresAt)
                    DashboardMealItem(
                        mealId = meal.id, 
                        name = meal.name, 
                        remainingPortions = meal.totalPortions, // MVP: ohne Events im UI‑Layer 
                        expiresInDays = expiresInDays, 
                        status = status
                    )
                }
                val nowEating = items.filter { it.status == MealStatus.SOON || it.status == MealStatus.EXPIRED }
                val thisWeek = items.filter { it.status == MealStatus.FRESH }
                val freezer = items.filter { it.status == MealStatus.FRESH } // MVP‑Placeholder; später storage==FREEZER
                _state.value = DashboardUiState(
                    nowEating = nowEating, 
                    thisWeek = thisWeek, 
                    freezerReserve = freezer, 
                    isLoading = false
                )
            }.onFailure { e -> _state.value = _state.value.copy(isLoading = false, error = e.message) }
        }
    }
}
