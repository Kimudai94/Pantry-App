import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodtracker.domain.model.Meal
import com.example.foodtracker.domain.usecase.ComputeMealStatus
import com.example.foodtracker.domain.usecase.ConsumeMealPortion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

class MealViewModel(
  private val mealId: Long, 
  private val loadMeal: suspend (Long) -> Meal, 
  private val saveMeal: suspend (Meal) -> Unit, 
  private val consumeMealPortion: ConsumeMealPortion, 
  private val computeMealStatus: ComputeMealStatus
) : ViewModel() {
  private val _state = MutableStateFlow(MealUiState(isLoading = true)) val state: StateFlow = _state.asStateFlow()

  fun load(today: LocalDate = LocalDate.now()) {
    viewModelScope.launch {
      _state.value = _state.value.copy(isLoading = true, error = null)
      runCatching { loadMeal(mealId) }
      .onSuccess { meal -> _state.value = meal.toUi(today) }
      .onFailure { e -> _state.value = _state.value.copy(isLoading = false, error = e.message) }
    }
  }

  fun eatOnePortion(today: LocalDate = LocalDate.now()) {
    viewModelScope.launch {
      val current = runCatching { loadMeal(mealId) }.getOrNull() ?: return@launch runCatching {
        val updated = consumeMealPortion(current)
        saveMeal(updated) updated
      }.onSuccess { meal -> _state.value = meal.toUi(today) }
      .onFailure { e -> _state.value = _state.value.copy(error = e.message) }
    }
  }

  private fun Meal.toUi(today: LocalDate): MealUiState {
    val expiresAt = prepDate.plusDays(shelfLifeDays.toLong())
    val status = computeMealStatus(this, today)
    return MealUiState(
      mealId = id, 
      name = name, 
      prepDate = prepDate, 
      storage = storage, 
      totalPortions = totalPortions, 
      remainingPortions = totalPortions, 
      shelfLifeDays = shelfLifeDays, 
      status = status, 
      expiresAt = expiresAt, 
      notes = notes, 
      isLoading = false
    )
  }
}
