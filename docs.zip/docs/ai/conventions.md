# PantryTracker — Coding Conventions (AI Contract)

Diese Datei ist für Claude verbindlich: Bitte strikt einhalten.

## Kotlin / Style
- Prefer immutable data classes (copy for updates)
- Keine Global States
- Nullable sparsam, klar dokumentiert
- Benennung:
  - Entity: ItemEntity
  - Domain: PantryItem
  - DAO: ItemDao
  - Repository: PantryRepository + PantryRepositoryImpl
  - UseCases: Verb-Noun (ObserveItems, UpsertItem, DeleteItem, ObserveExpiringSoon, ObserveLowStock)

## UI State Pattern (pro Screen)
- UiState ist data class mit klaren Feldern:
  - isLoading: Boolean
  - items: List<...>
  - query/filter/sort
  - errorMessage: String?
  - emptyStateHint: String? (optional)
- UiEvent ist sealed class, nur User-Intents:
  - OnQueryChanged(String)
  - OnFilterCategoryChanged(String?)
  - OnSortChanged(SortOption)
  - OnSaveClicked
  - OnDeleteClicked(id)
- Reducer-like:
  - Event -> new state (copy)
  - Side effects (DB ops) in viewModelScope

## Validation
- Validation findet im ViewModel statt.
- Fehler werden in UiState Feldern gehalten:
  - nameError: String?
  - quantityError: String?
  - minStockError: String?
- Save wird blockiert, wenn Fehler vorhanden.

## Compose UI
- Stateless Composables bevorzugen
- State hoisting: Screen nimmt state + eventDispatcher
- Scaffold + TopAppBar + FAB Standard
- Material 3 Komponenten
- Listen:
  - LazyColumn
  - stable keys (item.id)
- Fehleranzeige:
  - inline (Text / supportingText)
  - plus optional Snackbar über ScaffoldState/Host

## Navigation
- Routes zentral in ui/navigation
- Keine Navigation-Strings hardcoden in Screens
- itemId als navArgument (Long)

## Coroutines / Dispatchers
- Keine Dispatchers hardcoden in Domain
- Optional: DispatcherProvider in core/util, Default + Test
- In Tests: kotlinx-coroutines-test nutzen

## Room
- Entity:
  - @Entity(tableName="items")
  - id autoGenerate
  - updatedAtEpochMillis: Long immer setzen (bei upsert)
- DAO:
  - Nur Queries, keine Businesslogik
- Repository:
  - kapselt Mapping und Query-Parameter

## Sort / Null Handling
- expiryEpochDay null:
  - In EXPIRY_ASC: Nulls last (empfohlen)
  - Klar definieren und testen

## Logging
- Minimal, keine sensiblen Daten
- Für Debug ggf. Timber vermeiden (keine neue dep), nutze Log.d sparsam oder weglassen

## Testing Conventions
- Fakes statt Mocks, wenn möglich
- Testnamen: `whenX_thenY`
- ViewModel Tests prüfen State-Reihenfolge (z.B. Turbine)
- Room DAO Tests via inMemoryDatabaseBuilder (androidTest)