# PantryTracker — Architecture (Strict Layering)

## Module Layout
- Single module: `app/`

## Package / Layering (strict)
- data/
  - room/: Entity, Dao, Database, Converters
  - repository/: Interface + Implementierung
- domain/
  - model/: Domänenmodell (optional getrennt von Entity)
  - usecase/: UseCases
- ui/
  - navigation/: NavGraph, Routes
  - screens/: Compose Screens
  - components/: Wiederverwendbare UI-Komponenten
  - viewmodel/: ViewModels (StateFlow<UiState> + UiEvent)
- core/
  - util/: Date/Format Utils, DispatcherProvider (optional)

## Dependency Rules (allowed directions)
- ui -> domain
- domain -> (keine Android-Abhängigkeiten; idealerweise nur Kotlin)
- data -> domain (implementiert domain repository interfaces)
- core kann von allen genutzt werden (keine UI-Abhängigkeiten)

Verboten:
- ui -> data.room direkt
- domain -> data / room / android.*

## Core Domain Concepts

### Domain Model vs Entity
- Entity (Room): technische Persistenzdarstellung
- Domain Model (optional): saubere Domänenrepräsentation für UseCases/UI
- Mapping: data.mapper oder data.repository übernimmt Entity <-> Domain

Empfehlung:
- UseCases arbeiten auf Domain Model (PantryItem)
- Repository Interface liefert Domain Model Flows
- data layer mappt Entity zu Domain

## UseCases (Minimum Set)
- ObserveItems (alle / oder über SearchAndFilter)
- ObserveItemById
- UpsertItem
- DeleteItem
- ObserveExpiringSoon (Cutoff epochDay)
- ObserveLowStock
- SearchAndFilterItems (optional als Kombi-UseCase)

## Data Flow (MVVM)
1) UI sendet UiEvent an ViewModel
2) ViewModel:
   - validiert Eingaben (für Form)
   - ruft UseCases auf
   - reduziert Resultate in UiState
3) UI rendert State (rein deklarativ)
4) Room liefert Flows -> Repository -> UseCase -> ViewModel

## Navigation
- Routes als sealed class/enum
- NavGraph zentral in ui/navigation/
- Übergabe von itemId für Edit:
  - itemId optional (Add vs Edit)
  - argument default: -1 oder null

## Date Handling
- expiryEpochDay: Long? in DB
- UI verwendet LocalDate für Anzeige/Picker
- Converter/Utils in core/util:
  - LocalDate <-> epochDay
  - Formatierung (Locale-sensitiv)

## Error Handling
- Keine Exceptions als UI-Flow
- UseCases liefern:
  - entweder Result<T> / sealed class Outcome
  - oder werfen intern, werden im VM gefangen und in UiState.errorMessage gemappt
Empfehlung:
- Domain: sealed class AppError
- UI: errorMessage string (kurz) + optional technical detail (debug)

## No DI Library
- Simple Provider/Factory im app Einstieg:
  - Database singleton
  - Repository Konstruktor
  - UseCase Konstruktor
  - ViewModel Factory pro Screen
- Ziel: testbar durch Fake-Repositories / Fake-UseCases

## Performance & Reactivity
- Suche: debounce in VM (z. B. 250ms) oder sofort, aber Flow-basiert
- Sort/Filter: reaktiv über StateFlow kombinieren (combine)
- Datenbank: Queries als Flow -> UI automatisch aktualisiert