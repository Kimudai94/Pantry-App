# PantryTracker — Testing Strategy

## Goals
- Businesslogik & State-Transitions zuverlässig absichern
- Room Queries verifizieren (Flow + Filter/Sort)
- Tests schnell & deterministisch

---

## A) JVM Unit Tests (JUnit 5) — /src/test
### Required
1) UseCase Tests
- ExpiringSoon Logik:
  - cutoffEpochDay korrekt
  - Items mit expiry <= cutoff werden geliefert
  - Null expiry wird ausgeschlossen
- LowStock Logik:
  - quantity <= minStock => low
  - minStock null => nicht low
- Search/Filter/Sort:
  - query matches name (case-insensitive definieren!)
  - Filter nach category/location
  - Sort nach Name, Ablaufdatum (nulls last), updatedAt

2) ViewModel Tests
- Events -> State transitions:
  - OnQueryChanged aktualisiert query und result stream
  - Filter & sort ändern state und result
  - Form:
    - name leer => nameError gesetzt
    - quantity < 0 => quantityError
    - Save blockiert bei Errors
  - Save success => navigationsFlag oder transient message (im State modellieren)

### Tools
- kotlinx-coroutines-test:
  - StandardTestDispatcher + runTest
- Optional:
  - app.cash.turbine für Flow/StateFlow assertions (empfohlen)

---

## B) Android Instrumentation Tests (JUnit 4) — /src/androidTest
### Required
1) Room DAO Test (inMemoryDatabaseBuilder)
- upsert & observeAllItems liefert Insert
- searchAndFilter:
  - query/category/location
  - SortOption Varianten
- observeExpiringSoon(cutoffEpochDay)
- observeLowStock()

2) Optional: Compose UI Smoke Test
- Screen rendert (ItemsListScreen)
- Basisinteraktion:
  - Tippen in Search
  - Klick auf FAB navigiert zum Edit Screen (oder prüft callback)

---

## Test Data Guidelines
- Kleine, klare Fixtures:
  - Default item ohne expiry/minStock
  - Item mit expiry in 3 Tagen
  - Item mit expiry null
  - Item mit minStock 2.0 und quantity 2.0 / 1.0
- updatedAtEpochMillis: fixierte Werte für Sort-Tests

---

## Determinism / Flows
- In unit tests:
  - Flows aus FakeRepository kontrolliert liefern
  - StateFlow collection über Turbine oder collect in test scope
- In DAO tests:
  - runBlocking + first() / take(n) mit Timeout
  - ggf. Dispatchers/Main ersetzen (falls nötig)