# PantryTracker — Requirements (Detailed)

## Functional Requirements (10 Kernfunktionen)

1) CRUD Pantry-Items
- Item anlegen, bearbeiten, löschen

2) Mengen & Einheiten
- quantity: Double
- unit: String
- Validierung: quantity >= 0

3) Kategorien & Lagerorte
- category: String
- location: String
- Filterbarkeit nach category/location

4) Ablaufdatum (optional)
- Speicherung als epochDay: Long?
- UI konvertiert zu LocalDate

5) „Bald ablaufend“-Ansicht
- Items, die in den nächsten X Tagen ablaufen (Default X=7)

6) Mindestbestand & „Niedrigbestand“-Ansicht
- minStock: Double?
- low stock wenn quantity <= minStock

7) Listenansicht mit Suche (reaktiv)
- Textsuche über name
- Reaktiv beim Tippen (Flow/StateFlow)

8) Filter & Sortierung
- Filter: category, location
- Sort: Name, Ablaufdatum, Letztes Update (updatedAtEpochMillis)

9) Form-Validierung & Fehlerdarstellung
- name nicht leer
- quantity/minStock >= 0
- Fehler im UiState anzeigen (nicht nur Toast)

10) Offline Persistenz
- Room DB speichert alles lokal
- Daten bleiben nach App-Neustart erhalten

---

## Data Model: PantryItem (Felder pro Item)
- id: Long (autoGenerate)
- name: String (required)
- quantity: Double
- unit: String
- category: String
- location: String
- expiryEpochDay: Long? (optional)
- minStock: Double? (optional)
- notes: String?
- updatedAtEpochMillis: Long

### Validation Rules
- name.trim().isNotEmpty()
- quantity >= 0
- minStock == null OR minStock >= 0
- Optional: unit/category/location dürfen leer sein, aber UI sollte Default/Placeholder bieten

---

## Room / DAO Requirements

### Database
- Start mit version = 1
- Struktur migrationsfähig (Schema stabil, Migrationspfad später ergänzbar)

### DAO API
- observeAllItems(): Flow<List<ItemEntity>>
- observeById(id: Long): Flow<ItemEntity?>
- searchAndFilter(
    query: String,
    category: String?,
    location: String?,
    sort: SortOption
  ): Flow<List<ItemEntity>>
- observeExpiringSoon(cutoffEpochDay: Long): Flow<List<ItemEntity>>
- observeLowStock(): Flow<List<ItemEntity>>
- upsert(item: ItemEntity): Long (oder Unit, aber konsistent)
- deleteById(id: Long)

### SortOption (erforderlich)
- NAME_ASC (default)
- EXPIRY_ASC (nulls last, oder definierte Null-Behandlung)
- UPDATED_DESC

---

## UI / Navigation / State Requirements

### UI Basis
- Compose + Material 3
- Scaffold + TopAppBar + FloatingActionButton (FAB)

### Navigation (mind. 4 Screens)
- ItemsListScreen: Suche, Filter, Sortierung
- ItemEditScreen: Add/Edit + Validierung
- ExpiringSoonScreen
- LowStockScreen

### State Management
- Pro Screen:
  - UiState (data class)
  - UiEvent (sealed class)
- ViewModel: reducer-like (Event -> State)
- State via StateFlow<UiState>
- Form-Fehler im State (z. B. nameError, quantityError, minStockError)
- Sinnvolle Defaults & Initialisierung (z. B. Filter = null, sort = NAME_ASC, expiringDays = 7)
