# PantryTracker — Prompt Pack (Claude Code Workflow)

Diese Prompts sind für kurze Iterationen (kleine PRs) optimiert.

---

## Global Working Agreement (immer am Anfang)
> Du bist Senior Android Engineer. Arbeite in kleinen, reviewbaren Schritten.
> Regeln:
> 1) Stelle max. 5 Rückfragen bei Unklarheit.
> 2) Danach Plan: Schritte + betroffene Dateien.
> 3) Implementiere minimal lauffähig (Thin Slice).
> 4) Füge Tests hinzu (Unit + ggf. AndroidTest).
> 5) Self-Review: Risiken, Edge Cases, mögliche Bugs.

Kontext ist verbindlich:
- docs/ai/project-brief.md
- docs/ai/requirements.md
- docs/ai/architecture.md
- docs/ai/conventions.md

---

## Prompt: Architektur-Bootstrap (nach Template-Start)
Erzeuge die initiale Ordnerstruktur und den Composition Root (Provider/Factories) ohne DI Library.
Stelle sicher, dass:
- Layering eingehalten wird
- Navigation mit 4 Screens existiert
- ViewModels StateFlow<UiState> nutzen
- Room DB version=1 aufgesetzt ist
- Gradle (libs.versions.toml) vollständig ist

Output: Dateibaum + alle Dateien.

---

## Prompt: Feature Slice — CRUD Item
Implementiere CRUD (Add/Edit/Delete) end-to-end:
- ItemEditScreen mit Validierung (name, quantity, minStock)
- ItemsListScreen zeigt Items, Suche live
- Repository + UseCases
- Unit Tests:
  - ViewModel State transitions
  - UseCase logic (falls relevant)
- AndroidTest:
  - DAO inMemory Insert/Upsert/Delete

---

## Prompt: Filter/Sort/Search
Implementiere searchAndFilter inklusive SortOption:
- Filter category/location optional
- Sort by name, expiry (nulls last), updatedAt desc
- Tests:
  - Domain/UseCase tests für Sort/Filter Semantik
  - DAO Test für Query correctness

---

## Prompt: ExpiringSoon + LowStock
Implementiere:
- ExpiringSoonScreen (Default 7 Tage, anpassbar optional)
- LowStockScreen
- Tests:
  - cutoff logic
  - low stock logic (quantity <= minStock)

---

## Prompt: Build/Compile Check
Erstelle ein "How to run" und "Compile Check" Kapitel:
- ./gradlew test
- ./gradlew connectedAndroidTest
- ./gradlew assembleDebug
Nenne typische Stolperfallen (Compose/Room/Kapt/JUnit5).

---

## Prompt: Refactor in kleinen PRs
Refactor Ziel: <...>
Constraints:
- Kein Verhalten ändern
- Erst Regression Tests
- Danach Refactor
- PR < 400 Zeilen wenn möglich