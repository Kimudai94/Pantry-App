# PantryTracker — Architectural Decisions (ADRs)

## ADR-001: Offline-First, No Network
**Status:** Accepted  
**Decision:** App arbeitet vollständig offline, ohne Login/Cloud/Netzwerk.  
**Rationale:** Private Nutzung, maximale Einfachheit, Datenschutz, Robustheit.  
**Consequences:** Kein Sync; Persistenz muss zuverlässig lokal sein (Room).

---

## ADR-002: Single Module (app/)
**Status:** Accepted  
**Decision:** Single-module Gradle Projekt.  
**Rationale:** Weniger Overhead, schneller Start, private App.  
**Consequences:** Striktes Package-Layering erforderlich, um Modularitätsvorteile zu simulieren.

---

## ADR-003: MVVM + StateFlow (kein LiveData)
**Status:** Accepted  
**Decision:** ViewModels exposen StateFlow<UiState>, Events via sealed UiEvent.  
**Rationale:** Reaktiv, testbar, Compose-friendly, konsistentes State-Management.  
**Consequences:** Tests müssen coroutine-test nutzen; klare reducer-like Struktur.

---

## ADR-004: No DI Library
**Status:** Accepted  
**Decision:** Keine DI (Hilt/Koin). Konstruktor-Injektion + simple Factories/Provider.  
**Rationale:** Minimale Abhängigkeiten, Transparenz, einfache Tests.  
**Consequences:** Zentraler Composition Root (z.B. in Application/Activity).

---

## ADR-005: Room as Persistence
**Status:** Accepted  
**Decision:** Room mit Flow DAOs, DB version=1, migrationsfähig.  
**Rationale:** Offline, stabil, Query-Features.  
**Consequences:** AndroidTest für DAO erforderlich, KAPT sauber konfigurieren.

---

## ADR-006: Expiry stored as epochDay (Long?)
**Status:** Accepted  
**Decision:** expiryEpochDay in DB, UI konvertiert zu LocalDate.  
**Rationale:** Stabil, timezone-unabhängig, leicht vergleichbar.  
**Consequences:** Utils/Converter nötig, Null semantics definieren.

---

## ADR-007: Sorting semantics (Null expiry)
**Status:** Accepted  
**Decision:** Bei Sort nach expiry: Nulls last.  
**Rationale:** Items ohne Ablaufdatum sollen nicht „dringlich“ erscheinen.  
**Consequences:** Explizit in Tests abdecken.

---

## ADR-008: Testing split JUnit5 vs JUnit4
**Status:** Accepted  
**Decision:** Unit tests JUnit5, Android instrumentation JUnit4.  
**Rationale:** Moderne Unit Tests, Android Framework nutzt JUnit4 Runner.  
**Consequences:** Gradle config useJUnitPlatform + separate androidTest deps.