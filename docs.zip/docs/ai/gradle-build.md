# PantryTracker — Gradle & Build Rules

## Project Setup
- Kotlin DSL (settings.gradle.kts, build.gradle.kts, app/build.gradle.kts)
- Version Catalog `gradle/libs.versions.toml` bevorzugt
- minSdk: 26+
- targetSdk: "aktuell stabil" (zum Zeitpunkt der Implementierung)

## Required Dependencies (Minimum)
- Compose BOM
- material3
- ui-tooling (debug)
- lifecycle-viewmodel-compose
- navigation-compose
- room-runtime, room-ktx, room-compiler (kapt)
- coroutines (android + core)
- kotlinx-coroutines-test
- JUnit Jupiter (JUnit5) für unit tests
- androidx.test.ext:junit, espresso für androidTest
- optional: compose ui-test-junit4

## JUnit Setup Rules
- JVM Unit Tests: JUnit 5
  - Gradle: testOptions / useJUnitPlatform
  - dependencies: junit-jupiter-api + junit-jupiter-engine (runtime)
- Android Tests: JUnit 4
  - runner: androidx.test.runner.AndroidJUnitRunner
  - dependencies: androidx.test.ext:junit, espresso-core

## KAPT / Room Rules
- KAPT aktivieren
- room-compiler via kapt
- Java/Kotlin compatibility konsistent (AGP/Kotlin)

## How to Run (Build & Tests)
- JVM Unit Tests:
  - ./gradlew test
- Instrumentation / Android Tests:
  - ./gradlew connectedAndroidTest
- Build Debug APK:
  - ./gradlew assembleDebug

## Compile Check (Green Tasks)
Mindestens folgende Tasks müssen grün sein:
- :app:assembleDebug
- :app:testDebugUnitTest (oder allgemein ./gradlew test)
- :app:connectedDebugAndroidTest (oder ./gradlew connectedAndroidTest)

## Common Pitfalls (kurz)
- Compose Compiler / Kotlin Version mismatch
- Room + KAPT: fehlende kapt Konfiguration oder falsches plugin
- JUnit5: useJUnitPlatform vergessen -> Tests werden nicht gefunden
- AndroidTest vs UnitTest Dependencies vermischt
- Robolectric nicht nötig (hier nicht gefordert); Android Tests laufen auf Device/Emulator