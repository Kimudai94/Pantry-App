# PantryTracker — Project Brief (AI Context)

## Goal
Erstelle eine private, offline nutzbare Android-App „PantryTracker“ (Vorratsverwaltung).
Die App muss vollständig kompilierbaren Code, notwendige Gradle-Konfiguration/Abhängigkeiten sowie Tests enthalten.
Am Ende muss ein Compile-/Build-Check beschrieben werden (Gradle Tasks).

## Target Users / Scope
- Private Nutzung auf einem Android-Gerät
- Single-User, ohne Login
- Kein Cloud-Sync, kein Netzwerk, kein Backend
- Fokus: klare, testbare Architektur, saubere UI-States, robuste Persistenz

## Non-Goals (Explizit nicht)
- Multi-User, Accounts, Rollen
- Cloud/Sync/Backup über Netzwerk
- Push-Notifications, Server-Komponenten
- Monetarisierung, Analytics, Tracking

## Tech Stack (Binding)
- Kotlin
- Jetpack Compose (Material 3)
- Architektur: MVVM + StateFlow (kein LiveData)
- Persistenz: Room
- Async: Coroutines
- Navigation: androidx.navigation.compose
- Tests:
  - JVM Unit Tests: JUnit 5
  - Android/Instrumentation: JUnit 4
  - Korrekte Konfiguration (JUnit5 via useJUnitPlatform für JVM Tests)

## Project Constraints
- Single-Module Projekt: `app/`
- Keine DI-Library (kein Hilt/Koin). Stattdessen: Konstruktor-Injektion + Factory/Provider.
- Gradle Kotlin DSL (`.kts`)
- Version Catalog (`libs.versions.toml`) bevorzugt
- minSdk 26+, targetSdk „aktuell stabil“
- Package: `com.example.pantrytracker` (falls nicht anders angegeben)

## Definition of Done (Quality Gates)
- Keine Pseudocode-/TODO-Platzhalter für produktive Logik
- Alles kompiliert (Debug)
- JVM Tests laufen mit JUnit 5 (grün)
- Android Tests laufen mit JUnit 4 (grün) inkl. Room DAO inMemory Test
- Layering strikt eingehalten (data/domain/ui/core)
- UI: klare States (Loading/Empty/Error/Content) und Form-Validation im UiState

## Key Screens (Minimum)
- ItemsListScreen (Suche, Filter, Sortierung)
- ItemEditScreen (Add/Edit, Validierung)
- ExpiringSoonScreen
- LowStockScreen
