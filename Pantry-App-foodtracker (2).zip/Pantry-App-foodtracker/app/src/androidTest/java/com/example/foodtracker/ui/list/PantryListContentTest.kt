package com.example.foodtracker.ui.list

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test

class PantryListContentTest {

    @get:Rule
    val rule = createAndroidComposeRule<ComponentActivity>()

    @Test
    fun `empty state shows hint text`() {
        rule.setContent {
            PantryListContent(
                state = PantryListState(items = emptyList()),
                onAdd = {},
                onEdit = {},
                onToggleExpiringSoon = {}
            )
        }

        rule.onNodeWithText("Noch keine Einträge. Tippe auf + um einen Vorrat hinzuzufügen.")
            .assertIsDisplayed()
    }

    @Test
    fun `items are shown`() {
        rule.setContent {
            PantryListContent(
                state = PantryListState(items = listOf(
                    com.example.foodtracker.domain.model.PantryItem(
                        id = 1L, name = "Milch", quantity = 1.0,
                        unit = com.example.foodtracker.domain.model.UnitType.L,
                        category = com.example.foodtracker.domain.model.Category.DAIRY,
                        expirationDate = null
                    )
                )),
                onAdd = {},
                onEdit = {},
                onToggleExpiringSoon = {}
            )
        }

        rule.onNodeWithText("Milch").assertIsDisplayed()
    }
}
