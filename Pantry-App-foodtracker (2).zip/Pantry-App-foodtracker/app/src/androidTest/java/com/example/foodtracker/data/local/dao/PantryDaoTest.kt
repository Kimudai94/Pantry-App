package com.example.foodtracker.data.local.dao

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.foodtracker.data.local.db.AppDatabase
import com.example.foodtracker.data.local.entity.PantryItemEntity
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.time.LocalDate

@RunWith(AndroidJUnit4::class)
class PantryDaoTest {

    private lateinit var db: AppDatabase
    private lateinit var dao: PantryDao

    @Before
    fun setup() {
        val ctx: Context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        dao = db.pantryDao()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `getExpiringUntil returns only items with expiration date up to until`() = kotlinx.coroutines.runBlocking {
        val today = LocalDate.now()

        dao.upsert(item("A", today.plusDays(1)))
        dao.upsert(item("B", today.plusDays(10)))
        dao.upsert(item("C", null))

        val result = dao.getExpiringUntil(today.plusDays(3))
        assertEquals(listOf("A"), result.map { it.name })
    }

    private fun item(name: String, date: LocalDate?) = PantryItemEntity(
        name = name,
        quantity = 1.0,
        unit = "PCS",
        category = "OTHER",
        expirationDate = date,
        notes = null
    )
}
