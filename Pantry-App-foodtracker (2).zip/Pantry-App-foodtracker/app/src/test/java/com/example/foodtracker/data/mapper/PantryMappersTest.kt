package com.example.foodtracker.data.mapper

import com.example.foodtracker.data.local.entity.PantryItemEntity
import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.UnitType
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class PantryMappersTest {

    @Test
    fun `entity toDomain maps all fields`() {
        val entity = PantryItemEntity(
            id = 7L,
            name = "Milch",
            quantity = 1.5,
            unit = UnitType.L.name,
            category = Category.DAIRY.name,
            expirationDate = LocalDate.of(2026, 4, 20),
            notes = "Kühlschrank"
        )

        val domain = entity.toDomain()

        assertEquals(7L, domain.id)
        assertEquals("Milch", domain.name)
        assertEquals(1.5, domain.quantity, 0.0001)
        assertEquals(UnitType.L, domain.unit)
        assertEquals(Category.DAIRY, domain.category)
        assertEquals(LocalDate.of(2026, 4, 20), domain.expirationDate)
        assertEquals("Kühlschrank", domain.notes)
    }

    @Test
    fun `domain toEntity maps all fields`() {
        val date = LocalDate.of(2026, 4, 30)
        val item = com.example.foodtracker.domain.model.PantryItem(
            id = 9L,
            name = "Reis",
            quantity = 2.0,
            unit = UnitType.KG,
            category = Category.GRAIN,
            expirationDate = date,
            notes = null
        )

        val entity = item.toEntity()

        assertEquals(9L, entity.id)
        assertEquals("Reis", entity.name)
        assertEquals(2.0, entity.quantity, 0.0001)
        assertEquals(UnitType.KG.name, entity.unit)
        assertEquals(Category.GRAIN.name, entity.category)
        assertEquals(date, entity.expirationDate)
        assertEquals(null, entity.notes)
    }
}
