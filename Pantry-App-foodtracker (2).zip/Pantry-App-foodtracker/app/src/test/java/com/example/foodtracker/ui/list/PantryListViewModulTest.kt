package com.example.foodtracker.ui.list

import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.model.UnitType
import com.example.foodtracker.testdoubles.FakePantryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class PantryListViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var repo: FakePantryRepository
    private lateinit var vm: PantryListViewModel

    @Before
    fun setup() {
        Dispatchers.setMain(dispatcher)
        repo = FakePantryRepository()
        vm = PantryListViewModel(repo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `shows all items when filter disabled`() = runTest {
        repo.upsert(sample("A", LocalDate.now().plusDays(10)))
        repo.upsert(sample("B", LocalDate.now().plusDays(1)))

        val state = vm.uiState.value
        // stateIn initial is empty -> advance to collect updates
        advanceUntilIdle()

        val updated = vm.uiState.value
        assertEquals(2, updated.items.size)
    }

    @Test
    fun `filter expiring soon only returns items within days`() = runTest {
        repo.upsert(sample("Soon", LocalDate.now().plusDays(2)))
        repo.upsert(sample("Later", LocalDate.now().plusDays(10)))
        repo.upsert(sample("NoDate", null))

        vm.toggleExpiringSoon(true)
        vm.setDays(3)

        advanceUntilIdle()

        val updated = vm.uiState.value
        assertEquals(listOf("Soon"), updated.items.map { it.name })
    }

    private fun sample(name: String, date: LocalDate?) = PantryItem(
        id = 0L,
        name = name,
        quantity = 1.0,
        unit = UnitType.PCS,
        category = Category.OTHER,
        expirationDate = date,
        notes = null
    )
}
