package com.example.foodtracker.testdoubles

import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.repo.PantryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.time.LocalDate
import java.util.concurrent.atomic.AtomicLong

class FakePantryRepository : PantryRepository {

    private val idGen = AtomicLong(1L)
    private val itemsFlow = MutableStateFlow<List<PantryItem>>(emptyList())

    override fun observeAll(): Flow<List<PantryItem>> = itemsFlow

    override suspend fun getById(id: Long): PantryItem? =
        itemsFlow.value.firstOrNull { it.id == id }

    override suspend fun upsert(item: PantryItem): Long {
        val id = if (item.id == 0L) idGen.getAndIncrement() else item.id
        val newItem = item.copy(id = id)
        itemsFlow.update { list ->
            val filtered = list.filterNot { it.id == id }
            filtered + newItem
        }
        return id
    }

    override suspend fun deleteById(id: Long) {
        itemsFlow.update { list -> list.filterNot { it.id == id } }
    }

    override suspend fun expiringUntil(until: LocalDate): List<PantryItem> =
        itemsFlow.value.filter { it.expirationDate != null && !it.expirationDate!!.isAfter(until) }
}
