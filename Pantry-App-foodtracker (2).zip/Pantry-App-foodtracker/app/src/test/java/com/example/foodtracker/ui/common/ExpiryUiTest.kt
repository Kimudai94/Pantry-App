package com.example.foodtracker.ui.common

import org.junit.Assert.assertEquals
import org.junit.Test

class ExpiryUiTest {

    @Test fun `label null date`() = assertEquals("Kein Ablaufdatum", expiryLabel(null))
    @Test fun `label expired`() = assertEquals("Abgelaufen", expiryLabel(-1))
    @Test fun `label today`() = assertEquals("Läuft heute ab", expiryLabel(0))
    @Test fun `label tomorrow`() = assertEquals("Läuft morgen ab", expiryLabel(1))
    @Test fun `label in days`() = assertEquals("Läuft ab in 5 Tagen", expiryLabel(5))
}
