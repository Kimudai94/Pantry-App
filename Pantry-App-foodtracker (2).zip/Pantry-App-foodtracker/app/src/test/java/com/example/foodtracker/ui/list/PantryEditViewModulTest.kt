package com.example.foodtracker.ui.edit

import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.model.UnitType
import com.example.foodtracker.testdoubles.FakePantryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class PantryEditViewModelTest {

    private val dispatcher = StandardTestDispatcher()
    private lateinit var repo: FakePantryRepository
    private lateinit var vm: PantryEditViewModel

    @Before
    fun setup() {
        Dispatchers.setMain(dispatcher)
        repo = FakePantryRepository()
        vm = PantryEditViewModel(repo)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun `save fails when name blank`() = runTest {
        vm.onName("  ")
        vm.onQuantity("1")

        var done = false
        vm.save { done = true }
        advanceUntilIdle()

        assertFalse(done)
        assertEquals("Name darf nicht leer sein", vm.state.value.error)
    }

    @Test
    fun `save fails when quantity invalid`() = runTest {
        vm.onName("Äpfel")
        vm.onQuantity("abc")

        var done = false
        vm.save { done = true }
        advanceUntilIdle()

        assertFalse(done)
        assertEquals("Menge ist ungültig", vm.state.value.error)
    }

    @Test
    fun `save succeeds and persists item`() = runTest {
        vm.onName("Äpfel")
        vm.onQuantity("2")
        vm.onUnit(UnitType.PCS)
        vm.onCategory(Category.FRUIT)
        vm.onDate(LocalDate.now().plusDays(5))

        var done = false
        vm.save { done = true }
        advanceUntilIdle()

        assertTrue(done)
        assertNull(vm.state.value.error)

        val all = (repo.observeAll() as kotlinx.coroutines.flow.StateFlow<List<PantryItem>>).value
        assertEquals(1, all.size)
        assertEquals("Äpfel", all.first().name)
    }

    @Test
    fun `load fills state for existing item`() = runTest {
        val id = repo.upsert(
            PantryItem(
                name = "Milch",
                quantity = 1.0,
                unit = UnitType.L,
                category = Category.DAIRY,
                expirationDate = LocalDate.now().plusDays(3),
                notes = "kalt"
            )
        )

        vm.load(id)
        advanceUntilIdle()

        val s = vm.state.value
        assertEquals(id, s.id)
        assertEquals("Milch", s.name)
        assertEquals("1.0", s.quantity)
        assertEquals(UnitType.L, s.unit)
        assertEquals(Category.DAIRY, s.category)
        assertEquals("kalt", s.notes)
    }
}
