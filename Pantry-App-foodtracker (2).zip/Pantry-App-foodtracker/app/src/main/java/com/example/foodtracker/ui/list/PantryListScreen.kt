package com.example.foodtracker.ui.list

import com.example.foodtracker.ui.common.expiryColor
import com.example.foodtracker.ui.common.expiryLabel
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantryListScreen(
    onAdd: () -> Unit,
    onEdit: (Long) -> Unit,
    // In der echten App: ViewModel via hiltViewModel()/koinViewModel()
    viewModel: PantryListViewModel = error("Provide PantryListViewModel via DI")
) {
    val state by viewModel.uiState.collectAsState()
    PantryListContent(state, onAdd, onEdit)
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Vorräte") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Text("+") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {

            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = state.showOnlyExpiringSoon,
                    onCheckedChange = viewModel::toggleExpiringSoon
                )
                Spacer(Modifier.width(8.dp))
                Text("Nur bald ablaufend")
            }

            if (state.showOnlyExpiringSoon) {
                Spacer(Modifier.height(8.dp))
                Text("Innerhalb von ${state.expiringWithinDays} Tagen")
                Slider(
                    value = state.expiringWithinDays.toFloat(),
                    onValueChange = { viewModel.setDays(it.toLong().coerceIn(1, 30)) },
                    valueRange = 1f..30f
                )
            }

            Spacer(Modifier.height(12.dp))

            if (state.items.isEmpty()) {
                Text(
                    "Noch keine Einträge. Tippe auf + um einen Vorrat hinzuzufügen.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.items, key = { it.id }) { item ->
                        PantryRow(
                            name = item.name,
                            subtitle = "${item.quantity} ${item.unit.name} • ${item.category.name}",
                            expiryLabel = expiryLabel(item.daysToExpire()),
                            expiryColor = expiryColor(item.daysToExpire()),
                            onClick = { onEdit(item.id) },
                            onDelete = { viewModel.delete(item.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PantryRow(
    name: String,
    subtitle: String,
    expiryLabel: String,
    expiryColor: Color,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(2.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                AssistChip(
                    onClick = {},
                    label = { Text(expiryLabel) },
                    colors = AssistChipDefaults.assistChipColors(
                        labelColor = Color.White,
                        containerColor = expiryColor
                    )
                )
            }
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onDelete) { Text("Löschen") }
        }
    }
}

private fun expiryLabel(days: Long?): String = when {
    days == null -> "Kein Ablaufdatum"
    days < 0 -> "Abgelaufen"
    days == 0L -> "Läuft heute ab"
    days == 1L -> "Läuft morgen ab"
    else -> "Läuft ab in $days Tagen"
}

private fun expiryColor(days: Long?): Color = when {
    days == null -> Color.Gray
    days < 0 -> Color(0xFFB00020)     // rot
    days <= 2 -> Color(0xFFFF6F00)    // orange
    else -> Color(0xFF2E7D32)         // grün
}
