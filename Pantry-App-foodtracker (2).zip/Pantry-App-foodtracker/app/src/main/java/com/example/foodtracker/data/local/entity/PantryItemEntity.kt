package com.example.foodtracker.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.LocalDate

@Entity(
    tableName = "pantry_items",
    indices = [
        Index(value = ["expirationDate"]),
        Index(value = ["name"])
    ]
)
data class PantryItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val quantity: Double,
    val unit: String,
    val category: String,
    val expirationDate: LocalDate?,
    val notes: String?
)