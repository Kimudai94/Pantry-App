package com.example.foodtracker.ui.edit

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.model.UnitType
import com.example.foodtracker.domain.repo.PantryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class PantryEditState(
    val id: Long = 0L,
    val name: String = "",
    val quantity: String = "1",
    val unit: UnitType = UnitType.PCS,
    val category: Category = Category.OTHER,
    val expirationDate: LocalDate? = null,
    val notes: String = "",
    val error: String? = null,
    val isLoading: Boolean = false
)

class PantryEditViewModel(
    private val repo: PantryRepository
) : ViewModel() {

    private val _state = MutableStateFlow(PantryEditState())
    val state: StateFlow<PantryEditState> = _state

    fun load(id: Long) {
        if (id == 0L) return
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            val item = repo.getById(id)
            _state.update {
                if (item == null) it.copy(isLoading = false, error = "Eintrag nicht gefunden")
                else it.copy(
                    id = item.id,
                    name = item.name,
                    quantity = item.quantity.toString(),
                    unit = item.unit,
                    category = item.category,
                    expirationDate = item.expirationDate,
                    notes = item.notes.orEmpty(),
                    isLoading = false,
                    error = null
                )
            }
        }
    }

    fun onName(v: String) = _state.update { it.copy(name = v, error = null) }
    fun onQuantity(v: String) = _state.update { it.copy(quantity = v, error = null) }
    fun onUnit(v: UnitType) = _state.update { it.copy(unit = v, error = null) }
    fun onCategory(v: Category) = _state.update { it.copy(category = v, error = null) }
    fun onDate(v: LocalDate?) = _state.update { it.copy(expirationDate = v, error = null) }
    fun onNotes(v: String) = _state.update { it.copy(notes = v, error = null) }

    fun save(onDone: () -> Unit) {
        val s = _state.value
        val qty = s.quantity.replace(',', '.').toDoubleOrNull()
        when {
            s.name.isBlank() -> _state.update { it.copy(error = "Name darf nicht leer sein") }
            qty == null || qty < 0.0 -> _state.update { it.copy(error = "Menge ist ungültig") }
            else -> {
                viewModelScope.launch {
                    repo.upsert(
                        PantryItem(
                            id = s.id,
                            name = s.name.trim(),
                            quantity = qty,
                            unit = s.unit,
                            category = s.category,
                            expirationDate = s.expirationDate,
                            notes = s.notes.takeIf { it.isNotBlank() }
                        )
                    )
                    onDone()
                }
            }
        }
    }
}
