package com.example.foodtracker.domain.model

import java.time.LocalDate

data class PantryItem(
    val id: Long = 0L,
    val name: String,
    val quantity: Double,
    val unit: UnitType,
    val category: Category,
    val expirationDate: LocalDate?, // null = kein Ablaufdatum
    val notes: String? = null
)

enum class Category { FRUIT, VEGETABLE, MEAT, DAIRY, GRAIN, DRINK, OTHER }

enum class UnitType { PCS, G, KG, ML, L }