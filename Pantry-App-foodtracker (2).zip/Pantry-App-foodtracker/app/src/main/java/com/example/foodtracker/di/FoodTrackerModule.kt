package com.example.foodtracker.di

import android.content.Context
import androidx.room.Room
import com.example.foodtracker.data.local.dao.PantryDao
import com.example.foodtracker.data.local.db.AppDatabase
import com.example.foodtracker.data.repo.PantryRepositoryImpl
import com.example.foodtracker.domain.repo.PantryRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object FoodTrackerModule {

    @Provides
    @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "foodtracker.db")
            // MVP: für echte App später Migrationen!
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideDao(db: AppDatabase): PantryDao = db.pantryDao()

    @Provides
    @Singleton
    fun provideRepo(dao: PantryDao): PantryRepository = PantryRepositoryImpl(dao)
}
