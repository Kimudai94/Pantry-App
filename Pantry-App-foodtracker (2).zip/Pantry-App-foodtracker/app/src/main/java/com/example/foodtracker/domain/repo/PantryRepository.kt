package com.example.foodtracker.domain.repo

import kotlinx.coroutines.flow.Flow
import com.example.foodtracker.domain.model.PantryItem
import java.time.LocalDate

interface PantryRepository {
    fun observeAll(): Flow<List<PantryItem>>
    suspend fun getById(id: Long): PantryItem?
    suspend fun upsert(item: PantryItem): Long
    suspend fun deleteById(id: Long)
    suspend fun expiringUntil(until: LocalDate): List<PantryItem>
}