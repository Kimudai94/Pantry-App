package com.example.foodtracker.ui.edit

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.UnitType
import java.time.LocalDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PantryEditScreen(
    itemId: Long = 0L,
    onDone: () -> Unit,
    viewModel: PantryEditViewModel = error("Provide PantryEditViewModel via DI")
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(itemId) { viewModel.load(itemId) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (itemId == 0L) "Hinzufügen" else "Bearbeiten") }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.isLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

            OutlinedTextField(
                value = state.name,
                onValueChange = viewModel::onName,
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = state.quantity,
                onValueChange = viewModel::onQuantity,
                label = { Text("Menge") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            UnitDropdown(selected = state.unit, onSelected = viewModel::onUnit)
            CategoryDropdown(selected = state.category, onSelected = viewModel::onCategory)

            ExpirationPicker(
                date = state.expirationDate,
                onDate = viewModel::onDate
            )

            OutlinedTextField(
                value = state.notes,
                onValueChange = viewModel::onNotes,
                label = { Text("Notizen (optional)") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { viewModel.save(onDone) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Speichern")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UnitDropdown(selected: UnitType, onSelected: (UnitType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected.name,
            onValueChange = {},
            readOnly = true,
            label = { Text("Einheit") },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            UnitType.entries.forEach {
                DropdownMenuItem(
                    text = { Text(it.name) },
                    onClick = { onSelected(it); expanded = false }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryDropdown(selected: Category, onSelected: (Category) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selected.name,
            onValueChange = {},
            readOnly = true,
            label = { Text("Kategorie") },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Category.entries.forEach {
                DropdownMenuItem(
                    text = { Text(it.name) },
                    onClick = { onSelected(it); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun ExpirationPicker(date: LocalDate?, onDate: (LocalDate?) -> Unit) {
    // MVP: simple UI ohne Platform DatePicker Dialog, damit es überall buildet.
    // Optional: Material3 DatePickerDialog, wenn ihr Material3 DatePicker dependency nutzt.
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("Ablaufdatum: ${date?.toString() ?: "—"}")
        Row {
            TextButton(onClick = { onDate(null) }) { Text("Entfernen") }
            // Quick picks:
            TextButton(onClick = { onDate(LocalDate.now().plusDays(3)) }) { Text("+3T") }
            TextButton(onClick = { onDate(LocalDate.now().plusDays(7)) }) { Text("+7T") }
        }
    }
}
