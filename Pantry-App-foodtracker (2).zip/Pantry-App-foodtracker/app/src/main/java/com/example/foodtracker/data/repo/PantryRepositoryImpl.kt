package com.example.foodtracker.data.repo

import com.example.foodtracker.data.local.dao.PantryDao
import com.example.foodtracker.data.mapper.toDomain
import com.example.foodtracker.data.mapper.toEntity
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.repo.PantryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class PantryRepositoryImpl(
    private val dao: PantryDao
) : PantryRepository {

    override fun observeAll(): Flow<List<PantryItem>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getById(id: Long): PantryItem? =
        dao.getById(id)?.toDomain()

    override suspend fun upsert(item: PantryItem): Long =
        dao.upsert(item.toEntity())

    override suspend fun deleteById(id: Long) =
        dao.deleteById(id)

    override suspend fun expiringUntil(until: LocalDate): List<PantryItem> =
        dao.getExpiringUntil(until).map { it.toDomain() }
}