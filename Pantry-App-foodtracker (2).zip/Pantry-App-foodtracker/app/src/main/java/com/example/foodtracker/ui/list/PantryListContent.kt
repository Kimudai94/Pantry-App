package com.example.foodtracker.ui.list

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun PantryListContent(
    state: PantryListState,
    onAdd: () -> Unit,
    onEdit: (Long) -> Unit,
    onToggleExpiringSoon: (Boolean) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Vorräte") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAdd) { Text("+") } }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = state.showOnlyExpiringSoon, onCheckedChange = onToggleExpiringSoon)
                Spacer(Modifier.width(8.dp))
                Text("Nur bald ablaufend")
            }
            if (state.showOnlyExpiringSoon) {
                Spacer(Modifier.height(8.dp))
                Text("Innerhalb von ${state.expiringWithinDays} Tagen")
                Slider(
                    value = state.expiringWithinDays.toFloat(),
                    onValueChange = { viewModel.setDays(it.toLong().coerceIn(1, 30)) },
                    valueRange = 1f..30f
                )
            }
            Spacer(Modifier.height(12.dp))
            if (state.items.isEmpty()) {
                Text(
                    "Noch keine Einträge. Tippe auf + um einen Vorrat hinzuzufügen.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(state.items, key = { it.id }) { item ->
                        PantryRow(
                            name = item.name,
                            subtitle = "${item.quantity} ${item.unit.name} • ${item.category.name}",
                            expiryLabel = expiryLabel(item.daysToExpire()),
                            expiryColor = expiryColor(item.daysToExpire()),
                            onClick = { onEdit(item.id) },
                            onDelete = { viewModel.delete(item.id) }
                        )
                    }
                }
            }
        }
    }
}
