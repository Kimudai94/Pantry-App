package com.example.foodtracker.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.foodtracker.data.local.dao.PantryDao
import com.example.foodtracker.data.local.entity.PantryItemEntity


@Database(
    entities = [PantryItemEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
  abstract fun pantryDao(): PantryDao
}