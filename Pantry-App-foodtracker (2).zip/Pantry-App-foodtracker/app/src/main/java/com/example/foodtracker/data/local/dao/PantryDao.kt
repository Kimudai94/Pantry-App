package com.example.foodtracker.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import com.example.foodtracker.data.local.entity.PantryItemEntity
import java.time.LocalDate

@Dao
interface PantryDao {

    @Query("
        SELECT * FROM pantry_items ORDER BY (expirationDate IS NULL) ASC, expirationDate ASC, name ASC")
    fun observeAll(): Flow<List<PantryItemEntity>>

    @Query("SELECT * FROM pantry_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PantryItemEntity?

    @Query("SELECT * FROM pantry_items WHERE expirationDate IS NOT NULL AND expirationDate <= :until ORDER BY expirationDate ASC")
    suspend fun getExpiringUntil(until: LocalDate): List<PantryItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PantryItemEntity): Long

    @Delete
    suspend fun delete(entity: PantryItemEntity)

    @Query("DELETE FROM pantry_items WHERE id = :id")
    suspend fun deleteById(id: Long)
}