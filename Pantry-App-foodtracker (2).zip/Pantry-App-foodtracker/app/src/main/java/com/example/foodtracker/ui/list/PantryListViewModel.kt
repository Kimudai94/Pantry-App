package com.example.foodtracker.ui.list

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.repo.PantryRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class PantryListState(
    val items: List<PantryItem> = emptyList(),
    val showOnlyExpiringSoon: Boolean = false,
    val expiringWithinDays: Long = 3
)

class PantryListViewModel(
    private val repo: PantryRepository
) : ViewModel() {

    private val filter = MutableStateFlow(PantryListState())

    val uiState: StateFlow<PantryListState> =
        combine(filter, repo.observeAll()) { s, items ->
            val filtered = if (s.showOnlyExpiringSoon) {
                val until = LocalDate.now().plusDays(s.expiringWithinDays)
                items.filter { it.expirationDate != null && !it.expirationDate.isAfter(until) }
            } else items
            s.copy(items = filtered)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PantryListState())

    fun toggleExpiringSoon(enabled: Boolean) {
        filter.update { it.copy(showOnlyExpiringSoon = enabled) }
    }

    fun setDays(days: Long) {
        filter.update { it.copy(expiringWithinDays = days) }
    }

    fun delete(id: Long) = viewModelScope.launch { repo.deleteById(id) }
}

fun PantryItem.daysToExpire(today: LocalDate = LocalDate.now()): Long? =
    expirationDate?.let { ChronoUnit.DAYS.between(today, it) }
