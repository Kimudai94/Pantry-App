package com.example.foodtracker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.foodtracker.ui.edit.PantryEditScreen
import com.example.foodtracker.ui.list.PantryListScreen

object Routes {
    const val LIST = "pantry_list"
    const val EDIT = "pantry_edit"
    const val EDIT_WITH_ID = "pantry_edit/{id}"
}

@Composable
fun FoodTrackerNav() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = Routes.LIST) {
        composable(Routes.LIST) {
            PantryListScreen(
                onAdd = { navController.navigate(Routes.EDIT) },
                onEdit = { id -> navController.navigate("${Routes.EDIT}/$id") }
            )
        }
        composable(Routes.EDIT) {
            PantryEditScreen(onDone = { navController.popBackStack() })
        }
        composable(
            route = Routes.EDIT_WITH_ID,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) {
            val id = it.arguments?.getLong("id") ?: 0L
            PantryEditScreen(itemId = id, onDone = { navController.popBackStack() })
        }
    }
}
