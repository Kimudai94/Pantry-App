package com.example.foodtracker.data.mapper

import com.example.foodtracker.data.local.entity.PantryItemEntity
import com.example.foodtracker.domain.model.Category
import com.example.foodtracker.domain.model.PantryItem
import com.example.foodtracker.domain.model.UnitType

fun PantryItemEntity.toDomain(): PantryItem = PantryItem(
    id = id,
    name = name,
    quantity = quantity,
    unit = UnitType.valueOf(unit),
    category = Category.valueOf(category),
    expirationDate = expirationDate,
    notes = notes
)

fun PantryItem.toEntity(): PantryItemEntity = PantryItemEntity(
    id = id,
    name = name,
    quantity = quantity,
    unit = unit.name,
    category = category.name,
    expirationDate = expirationDate,
    notes = notes
)