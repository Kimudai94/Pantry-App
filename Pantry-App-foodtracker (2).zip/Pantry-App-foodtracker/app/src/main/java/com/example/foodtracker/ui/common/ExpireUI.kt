package com.example.foodtracker.ui.common

import androidx.compose.ui.graphics.Color

fun expiryLabel(days: Long?): String = when {
    days == null -> "Kein Ablaufdatum"
    days < 0 -> "Abgelaufen"
    days == 0L -> "Läuft heute ab"
    days == 1L -> "Läuft morgen ab"
    else -> "Läuft ab in $days Tagen"
}

fun expiryColor(days: Long?): Color = when {
    days == null -> Color.Gray
    days < 0 -> Color(0xFFB00020)     // rot
    days <= 2 -> Color(0xFFFF6F00)    // orange
    else -> Color(0xFF2E7D32)         // grün
}
