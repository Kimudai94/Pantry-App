package com.example.foodtracker.di

import android.content.Context
import androidx.room.Room
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import com.example.foodtracker.data.local.db.AppDatabase
import com.example.foodtracker.data.local.dao.PantryDao
import com.example.foodtracker.data.repo.PantryRepositoryImpl
import com.example.foodtracker.domain.repo.PantryRepository
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepoModule {
    @Binds abstract fun bindPantryRepo(impl: PantryRepositoryImpl): PantryRepository
}

@Module
@InstallIn(SingletonComponent::class)
object DbModule {

    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "pantry.db")
            .fallbackToDestructiveMigration() // später sauber migrieren
            .build()

    @Provides
    fun providePantryDao(db: AppDatabase): PantryDao = db.pantryDao()
}