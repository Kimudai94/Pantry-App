/**
 * Performance Baseline Tests for Pantry-App
 * Testplan: PERF-001 to PERF-008
 * 
 * These tests establish performance baselines for critical operations.
 * Target values are set to ensure app remains responsive.
 */

import { getMhdStatus } from '../src/utils/mhdStatus';
import { Product } from '../src/types/product';

describe('Performance Baseline Tests', () => {
  /**
   * PERF-001: HomeScreen with 100 Products Load
   * Target: <500ms
   * Description: Loading and rendering 100 products should be fast
   */
  test('PERF-001: Load 100 Products in HomeScreen < 500ms', () => {
    const mockProducts: Product[] = Array.from({ length: 100 }, (_, i) => ({
      id: i + 1,
      name: `Product ${i + 1}`,
      quantity: Math.random() * 100,
      unit: ['g', 'ml', 'l', 'kg', 'Stück'][i % 5],
      mhd: new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      price: Math.random() * 100,
    }));

    const startTime = performance.now();
    
    // Simulate loading and filtering
    const result = mockProducts.filter((p) =>
      p.name.toLowerCase().includes('product')
    );
    
    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(500);
    expect(result).toHaveLength(100);
  });

  /**
   * PERF-002: HomeScreen with 1000 Products Load
   * Target: <1000ms (1 second)
   * Description: Loading 1000 products should complete within 1 second
   */
  test('PERF-002: Load 1000 Products in HomeScreen < 1000ms', () => {
    const mockProducts: Product[] = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 1,
      name: `Product ${i + 1}`,
      quantity: Math.random() * 100,
      unit: ['g', 'ml', 'l', 'kg', 'Stück'][i % 5],
      mhd: new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      price: Math.random() * 100,
    }));

    const startTime = performance.now();
    const result = mockProducts;
    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(1000);
    expect(result).toHaveLength(1000);
  });

  /**
   * PERF-003: Search in 1000 Products
   * Target: <200ms
   * Description: Filtering 1000 products by search term should be fast
   */
  test('PERF-003: Search in 1000 Products < 200ms', () => {
    const mockProducts: Product[] = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 1,
      name: i % 10 === 0 ? 'Apfel Juice' : `Product ${i}`,
      quantity: Math.random() * 100,
      unit: 'l',
      price: Math.random() * 100,
    }));

    const searchTerm = 'apfel';
    const startTime = performance.now();

    const filtered = mockProducts.filter((p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(200);
    expect(filtered.length).toBeGreaterThan(0);
  });

  /**
   * PERF-004: Sort 1000 Products by Name
   * Target: <300ms
   * Description: Sorting 1000 products alphabetically should be fast
   */
  test('PERF-004: Sort 1000 Products by Name < 300ms', () => {
    const mockProducts: Product[] = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 1,
      name: `Product ${String(Math.random()).substring(2, 8)}`,
      quantity: Math.random() * 100,
      unit: 'l',
      price: Math.random() * 100,
    }));

    const startTime = performance.now();

    const sorted = [...mockProducts].sort((a, b) =>
      a.name.localeCompare(b.name)
    );

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(300);
    // Verify sorted is in ascending order
    for (let i = 0; i < sorted.length - 1; i++) {
      expect(sorted[i].name.localeCompare(sorted[i + 1].name)).toBeLessThanOrEqual(0);
    }
  });

  /**
   * PERF-005: Add Product (Database Write Simulation)
   * Target: <100ms
   * Description: Adding a product should be instant
   */
  test('PERF-005: Add Product (DB write) < 100ms', () => {
    const newProduct: Product = {
      id: 999,
      name: 'Test Product',
      quantity: 1,
      unit: 'l',
      mhd: '2025-12-31',
      price: 1.99,
    };

    const startTime = performance.now();

    // Simulate DB write
    const products: Product[] = [];
    products.push(newProduct);

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(100);
    expect(products).toHaveLength(1);
  });

  /**
   * PERF-006: Delete Product (Database Delete Simulation)
   * Target: <100ms
   * Description: Deleting a product should be instant
   */
  test('PERF-006: Delete Product (DB delete) < 100ms', () => {
    const products: Product[] = Array.from({ length: 100 }, (_, i) => ({
      id: i + 1,
      name: `Product ${i}`,
      quantity: 1,
      unit: 'l',
    }));

    const startTime = performance.now();

    // Simulate DB delete
    const filtered = products.filter((p) => p.id !== 50);

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(100);
    expect(filtered).toHaveLength(99);
  });

  /**
   * PERF-007: MHD Status Calculation for 1000 Products
   * Target: <500ms
   * Description: Calculating MHD status for all products should be fast
   */
  test('PERF-007: Calculate MHD Status for 1000 Products < 500ms', () => {
    const mockProducts: Product[] = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 1,
      name: `Product ${i}`,
      quantity: 1,
      unit: 'l',
      mhd: new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
    }));

    const startTime = performance.now();

    const statuses = mockProducts.map((p) => getMhdStatus(p.mhd));

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(500);
    expect(statuses).toHaveLength(1000);
    expect(statuses.every((s) => s.type !== undefined)).toBe(true);
  });

  /**
   * PERF-008: Combined Filter + Sort on 1000 Products
   * Target: <400ms
   * Description: Filtering and sorting together should still be fast
   */
  test('PERF-008: Filter + Sort 1000 Products < 400ms', () => {
    const mockProducts: Product[] = Array.from({ length: 1000 }, (_, i) => ({
      id: i + 1,
      name: i % 5 === 0 ? 'Apfel' : `Product ${i}`,
      quantity: Math.random() * 100,
      unit: 'l',
      mhd: new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      price: Math.random() * 100,
    }));

    const searchTerm = 'apfel';
    const startTime = performance.now();

    // Filter
    const filtered = mockProducts.filter((p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Sort
    const sorted = [...filtered].sort((a, b) =>
      a.name.localeCompare(b.name)
    );

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(400);
    expect(sorted.length).toBeGreaterThan(0);
  });

  /**
   * Performance Regression Test
   * Ensures that consecutive operations don't degrade performance
   */
  test('Performance: Multiple operations should maintain speed', () => {
    const mockProducts: Product[] = Array.from({ length: 500 }, (_, i) => ({
      id: i + 1,
      name: `Product ${i}`,
      quantity: Math.random() * 100,
      unit: 'l',
      mhd: new Date(Date.now() + Math.random() * 90 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0],
      price: Math.random() * 100,
    }));

    const startTime = performance.now();

    // Simulate multiple operations
    const search = mockProducts.filter((p) => p.name.includes('Product'));
    const sorted = [...search].sort((a, b) => a.name.localeCompare(b.name));
    const filtered = sorted.filter((p) => p.id > 250);
    const withStatus = filtered.map((p) => ({
      ...p,
      status: getMhdStatus(p.mhd),
    }));

    const endTime = performance.now();
    const duration = endTime - startTime;

    expect(duration).toBeLessThan(200);
    expect(withStatus).toHaveLength(250);
  });
});
