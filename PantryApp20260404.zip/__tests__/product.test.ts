import { Product } from '../src/types/product';

/**
 * @testplan PT-001 to PT-013: Product Type validation and field handling
 */
describe('Product Type', () => {
  test('PT-001: should create product with all fields', () => {
    const product: Product = {
      id: 1,
      name: 'Milch',
      quantity: 1,
      unit: 'l',
      mhd: '2024-12-31',
      price: 1.99,
      created_at: '2024-10-01T00:00:00Z',
      updated_at: '2024-10-01T00:00:00Z',
    };

    expect(product.id).toBe(1);
    expect(product.name).toBe('Milch');
    expect(product.quantity).toBe(1);
    expect(product.unit).toBe('l');
    expect(product.mhd).toBe('2024-12-31');
    expect(product.price).toBe(1.99);
  });

  test('PT-002: should create product with required fields only', () => {
    const product: Product = {
      id: 2,
      name: 'Butter',
      quantity: 250,
      unit: 'g',
    };

    expect(product.id).toBe(2);
    expect(product.name).toBe('Butter');
    expect(product.quantity).toBe(250);
    expect(product.unit).toBe('g');
    expect(product.mhd).toBeUndefined();
    expect(product.price).toBeUndefined();
  });

  test('PT-003: should handle numeric quantities', () => {
    const products: Product[] = [
      { id: 1, name: 'Item1', quantity: 100, unit: 'g' },
      { id: 2, name: 'Item2', quantity: 0.5, unit: 'kg' },
      { id: 3, name: 'Item3', quantity: 1000, unit: 'ml' },
    ];

    expect(products[0].quantity).toBe(100);
    expect(products[1].quantity).toBe(0.5);
    expect(products[2].quantity).toBe(1000);
  });

  test('PT-004: should validate product with common units', () => {
    const units = ['g', 'ml', 'l', 'kg', 'stck', 'pack'];

    units.forEach((unit) => {
      const product: Product = {
        id: 1,
        name: 'Test',
        quantity: 100,
        unit: unit,
      };

      expect(product.unit).toBe(unit);
    });
  });

  test('PT-005: should handle products without timestamps', () => {
    const product: Product = {
      id: 1,
      name: 'Test Product',
      quantity: 50,
      unit: 'g',
    };

    expect(product.created_at).toBeUndefined();
    expect(product.updated_at).toBeUndefined();
  });

  test('PT-006: should handle products with MHD but no price', () => {
    const product: Product = {
      id: 1,
      name: 'Perishable Item',
      quantity: 1,
      unit: 'l',
      mhd: '2024-11-15',
    };

    expect(product.mhd).toBe('2024-11-15');
    expect(product.price).toBeUndefined();
  });

  test('PT-007: should handle products with price but no MHD', () => {
    const product: Product = {
      id: 1,
      name: 'Non-Perishable Item',
      quantity: 10,
      unit: 'stck',
      price: 15.99,
    };

    expect(product.price).toBe(15.99);
    expect(product.mhd).toBeUndefined();
  });

  test('PT-008: should handle zero price', () => {
    const product: Product = {
      id: 1,
      name: 'Free Sample',
      quantity: 1,
      unit: 'pack',
      price: 0,
    };

    expect(product.price).toBe(0);
  });

  test('PT-009: should validate product array of different states', () => {
    const products: Product[] = [
      {
        id: 1,
        name: 'Product1',
        quantity: 100,
        unit: 'g',
        mhd: '2024-12-31',
        price: 1.99,
      },
      {
        id: 2,
        name: 'Product2',
        quantity: 500,
        unit: 'ml',
      },
      {
        id: 3,
        name: 'Product3',
        quantity: 1,
        unit: 'l',
        price: 2.50,
      },
    ];

    expect(products).toHaveLength(3);
    expect(products.every((p) => p.id > 0)).toBe(true);
    expect(products.every((p) => p.name.length > 0)).toBe(true);
  });

  test('PT-010: should handle MHD date format validation', () => {
    const validMhdFormats = [
      '2024-12-31',
      '2025-01-01',
      '2024-02-29',
    ];

    validMhdFormats.forEach((mhd) => {
      const product: Product = {
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'l',
        mhd: mhd,
      };

      expect(product.mhd).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    });
  });

  test('PT-011: should handle large product quantities', () => {
    const product: Product = {
      id: 1,
      name: 'Bulk Item',
      quantity: 99999.99,
      unit: 'g',
    };

    expect(product.quantity).toBe(99999.99);
  });

  test('PT-012: should handle special characters in product names', () => {
    const specialNames = [
      'Käse & Butter',
      'Öl (Bio)',
      'Müsli™',
      'Café au Lait',
    ];

    specialNames.forEach((name) => {
      const product: Product = {
        id: 1,
        name: name,
        quantity: 1,
        unit: 'l',
      };

      expect(product.name).toBe(name);
    });
  });

  test('PT-013: should validate timestamps format when provided', () => {
    const product: Product = {
      id: 1,
      name: 'Test',
      quantity: 100,
      unit: 'g',
      created_at: '2024-10-01T10:30:00Z',
      updated_at: '2024-10-02T15:45:30Z',
    };

    expect(product.created_at).toBeDefined();
    expect(product.updated_at).toBeDefined();
    expect(product.created_at).toMatch(/^\d{4}-\d{2}-\d{2}T/);
  });
});
