import { Product } from '../src/types/product';
import {
  validateProduct,
  validateProductName,
  validateProductQuantity,
  validateProductPrice,
  isValidMhdDate,
} from '../src/utils/validation';

describe('Edit Product Screen Logic', () => {
  const mockProduct: Product = {
    id: 1,
    name: 'Milch',
    quantity: 1,
    unit: 'l',
    mhd: '2024-12-31',
    price: 1.99,
    created_at: '2024-10-01',
    updated_at: '2024-10-01',
  };

  describe('Form Population & Initial State', () => {
    test('should populate form with product data', () => {
      expect(mockProduct.name).toBe('Milch');
      expect(mockProduct.quantity).toBe(1);
      expect(mockProduct.unit).toBe('l');
      expect(mockProduct.mhd).toBe('2024-12-31');
      expect(mockProduct.price).toBe(1.99);
    });

    test('should handle product with optional fields present', () => {
      expect(mockProduct.mhd).toBeDefined();
      expect(mockProduct.price).toBeDefined();
    });

    test('should handle product without optional fields', () => {
      const productWithoutOptional: Product = {
        id: 2,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
      };

      expect(productWithoutOptional.mhd).toBeUndefined();
      expect(productWithoutOptional.price).toBeUndefined();
    });
  });

  describe('Form Field Validation', () => {
    test('should validate updated product name', () => {
      const result = validateProductName('Milch Premium');
      expect(result.valid).toBe(true);
    });

    test('should reject empty product name', () => {
      const result = validateProductName('');
      expect(result.valid).toBe(false);
    });

    test('should validate updated quantity', () => {
      const result = validateProductQuantity('2');
      expect(result.valid).toBe(true);
    });

    test('should reject negative quantity on update', () => {
      const result = validateProductQuantity('-10');
      expect(result.valid).toBe(false);
    });

    test('should validate updated price', () => {
      const result = validateProductPrice('2.99');
      expect(result.valid).toBe(true);
    });

    test('should validate updated MHD', () => {
      const isValid = isValidMhdDate('2025-01-15');
      expect(isValid).toBe(true);
    });

    test('should validate MHD change to undefined', () => {
      const result = validateProduct({
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
      });
      expect(result.valid).toBe(true);
    });
  });

  describe('Product Update Operations', () => {
    test('should validate updated product with all changes', () => {
      const updatedProduct: Partial<Product> = {
        id: mockProduct.id,
        name: 'Milch Premium',
        quantity: 2,
        unit: 'l',
        mhd: '2025-01-15',
        price: 2.99,
      };

      const result = validateProduct(updatedProduct);
      expect(result.valid).toBe(true);
    });

    test('should validate update with name change only', () => {
      const updatedProduct: Partial<Product> = {
        ...mockProduct,
        name: 'Milch Premium',
      };

      const result = validateProduct(updatedProduct);
      expect(result.valid).toBe(true);
    });

    test('should validate update with quantity change', () => {
      const updatedProduct: Partial<Product> = {
        ...mockProduct,
        quantity: 5,
      };

      const result = validateProduct(updatedProduct);
      expect(result.valid).toBe(true);
    });

    test('should validate update with price change', () => {
      const updatedProduct: Partial<Product> = {
        ...mockProduct,
        price: 3.50,
      };

      const result = validateProduct(updatedProduct);
      expect(result.valid).toBe(true);
    });

    test('should validate update removing optional fields', () => {
      const updatedProduct: Partial<Product> = {
        ...mockProduct,
        mhd: undefined,
        price: undefined,
      };

      const result = validateProduct(updatedProduct);
      expect(result.valid).toBe(true);
    });
  });

  describe('Validation On Save', () => {
    test('should catch invalid name on save', () => {
      const product: Partial<Product> = {
        id: 1,
        name: '',
        quantity: 1,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });

    test('should catch invalid quantity on save', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: -5,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });

    test('should catch invalid MHD on save', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
        mhd: 'invalid-date',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'mhd')).toBe(true);
    });

    test('should catch invalid price on save', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
        price: -50,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'price')).toBe(true);
    });
  });

  describe('Detect Changed Fields', () => {
    test('should detect name changes', () => {
      const original = mockProduct.name;
      const updated = 'Milch Premium';
      expect(original !== updated).toBe(true);
    });

    test('should detect quantity changes', () => {
      const original = mockProduct.quantity;
      const updated = 5;
      expect(original !== updated).toBe(true);
    });

    test('should detect price changes', () => {
      const original = mockProduct.price;
      const updated = 3.50;
      expect(original !== updated).toBe(true);
    });

    test('should detect no changes when values are same', () => {
      const original = mockProduct.name;
      const updated = 'Milch';
      expect(original === updated).toBe(true);
    });
  });

  describe('Field Modifications', () => {
    test('should allow name field modification', () => {
      let name = mockProduct.name;
      name = 'Milch Premium';

      expect(name).toBe('Milch Premium');
    });

    test('should allow quantity field modification', () => {
      const quantityStr = mockProduct.quantity.toString();
      expect(quantityStr).toBe('1');

      const modifiedQty = parseFloat('2.5');
      expect(modifiedQty).toBe(2.5);
    });

    test('should allow unit selection change', () => {
      let unit = mockProduct.unit;
      unit = 'ml';

      expect(unit).toBe('ml');
    });

    test('should allow MHD field modification', () => {
      let mhd = mockProduct.mhd;
      mhd = '2025-01-01';

      expect(mhd).toBe('2025-01-01');
    });

    test('should allow price field modification', () => {
      let price = mockProduct.price;
      price = 2.99;

      expect(price).toBe(2.99);
    });

    test('should handle navigation back', () => {
      const navigation = {
        goBack: jest.fn(),
      };

      navigation.goBack();
      expect(navigation.goBack).toHaveBeenCalled();
    });
  });
});
