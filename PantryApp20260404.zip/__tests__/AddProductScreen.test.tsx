import {
  validateProduct,
  validateProductName,
  validateProductQuantity,
  validateProductPrice,
  isValidMhdDate,
} from '../src/utils/validation';
import { Product } from '../src/types/product';

describe('Add Product Screen Logic', () => {
  describe('Form Validation - using validation utilities', () => {
    test('should require product name (empty string)', () => {
      const result = validateProductName('');
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });

    test('should require product quantity (empty string)', () => {
      const result = validateProductQuantity('');
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });

    test('should accept valid name and quantity', () => {
      const nameResult = validateProductName('Milch');
      const quantityResult = validateProductQuantity('100');

      expect(nameResult.valid).toBe(true);
      expect(quantityResult.valid).toBe(true);
    });

    test('should validate product with all required fields', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
    });
  });

  describe('Quantity Validation', () => {
    test('should accept valid positive quantity', () => {
      const result = validateProductQuantity('250');
      expect(result.valid).toBe(true);
    });

    test('should accept decimal quantities', () => {
      const result = validateProductQuantity('250.5');
      expect(result.valid).toBe(true);
    });

    test('should accept zero quantity', () => {
      const result = validateProductQuantity('0');
      expect(result.valid).toBe(true);
    });

    test('should reject negative quantities', () => {
      const result = validateProductQuantity('-10');
      expect(result.valid).toBe(false);
    });

    test('should reject non-numeric quantities', () => {
      const result = validateProductQuantity('abc');
      expect(result.valid).toBe(false);
    });
  });

  describe('Price Validation', () => {
    test('should accept valid price', () => {
      const result = validateProductPrice('1.99');
      expect(result.valid).toBe(true);
    });

    test('should accept zero price', () => {
      const result = validateProductPrice(0);
      expect(result.valid).toBe(true);
    });

    test('should accept undefined price (optional)', () => {
      const result = validateProductPrice(undefined);
      expect(result.valid).toBe(true);
    });

    test('should reject negative price', () => {
      const result = validateProductPrice('-5');
      expect(result.valid).toBe(false);
    });

    test('should reject non-numeric price', () => {
      const result = validateProductPrice('abc');
      expect(result.valid).toBe(false);
    });
  });

  describe('MHD Date Validation', () => {
    test('should validate MHD date format', () => {
      const isValid = isValidMhdDate('2024-12-31');
      expect(isValid).toBe(true);
    });

    test('should validate valid leap year date', () => {
      const isValid = isValidMhdDate('2024-02-29');
      expect(isValid).toBe(true);
    });

    test('should reject invalid date format', () => {
      const isValid = isValidMhdDate('31-12-2024');
      expect(isValid).toBe(false);
    });

    test('should reject invalid dates like 02-30', () => {
      const isValid = isValidMhdDate('2024-02-30');
      expect(isValid).toBe(false);
    });

    test('should accept empty/optional MHD', () => {
      const result = validateProduct({
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
      });
      expect(result.valid).toBe(true);
    });
  });

  describe('Complete Product Creation', () => {
    test('should validate complete product with all fields', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: '2024-12-31',
        price: 1.99,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should validate product with required fields only', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
    });

    test('should validate product with name, quantity, unit, and price', () => {
      const product: Partial<Product> = {
        id: 2,
        name: 'Käse',
        quantity: 200,
        unit: 'g',
        price: 3.50,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
    });

    test('should validate product with MHD and price', () => {
      const product: Partial<Product> = {
        id: 3,
        name: 'Joghurt',
        quantity: 500,
        unit: 'g',
        mhd: '2024-11-30',
        price: 2.99,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
    });
  });

  describe('Form Error Handling', () => {
    test('should catch missing required name', () => {
      const product: Partial<Product> = {
        id: 1,
        quantity: 100,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });

    test('should catch missing required quantity', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });

    test('should catch missing required unit', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 100,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'unit')).toBe(true);
    });

    test('should catch invalid MHD format', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 100,
        unit: 'g',
        mhd: 'invalid-date',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'mhd')).toBe(true);
    });

    test('should catch negative price', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 100,
        unit: 'g',
        price: -10,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'price')).toBe(true);
    });

    test('should catch negative quantity', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: -5,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });
  });
});
