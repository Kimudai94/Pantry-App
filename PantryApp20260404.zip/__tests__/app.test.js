import { Product } from '../src/types/product';
import { validateProduct, validateProductQuantity } from '../src/utils/validation';

describe('App Configuration & Metadata', () => {
  test('should have correct app name from config', () => {
    const appConfig = require('../app.json');
    expect(appConfig.name).toBe('PantryApp');
  });

  test('should validate app json structure', () => {
    const config = {
      name: 'PantryApp',
      displayName: 'Pantry App',
      version: '1.0.0',
      description: 'Offline Pantry-Tracker App für Android',
    };

    expect(config.name).toBe('PantryApp');
    expect(config.displayName).toBeTruthy();
    expect(config.version).toMatch(/^\d+\.\d+\.\d+$/);
    expect(config.description).toContain('Pantry');
  });

  test('should have offline-first capability', () => {
    const appFeatures = {
      offline: true,
      sync: true,
      persistence: true,
    };

    expect(appFeatures.offline).toBe(true);
    expect(appFeatures.persistence).toBe(true);
  });
});

describe('Product Data Validation in App', () => {
  test('should validate product data with all required fields', () => {
    const product: Product = {
      id: 1,
      name: 'Test Product',
      quantity: 100,
      unit: 'g',
    };

    const result = validateProduct(product);
    expect(result.valid).toBe(true);
  });

  test('should handle product data with all optional fields', () => {
    const product: Product = {
      id: 1,
      name: 'Test Product',
      quantity: 100,
      unit: 'g',
      mhd: '2024-12-31',
      price: 1.99,
      created_at: '2024-01-01T10:00:00Z',
      updated_at: '2024-01-01T10:00:00Z',
    };

    const result = validateProduct(product);
    expect(result.valid).toBe(true);
  });

  test('should reject invalid product data', () => {
    const product: Partial<Product> = {
      id: 1,
      name: '',  // Invalid: empty
      quantity: -5,  // Invalid: negative
      unit: 'g',
    };

    const result = validateProduct(product);
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
  });

  test('should validate quantity as non-negative', () => {
    const validQuantities = [0, 1, 100, 250.5, 1000];

    validQuantities.forEach(qty => {
      const result = validateProductQuantity(qty);
      expect(result.valid).toBe(true);
    });
  });

  test('should reject negative quantity', () => {
    const result = validateProductQuantity(-10);
    expect(result.valid).toBe(false);
  });

  test('should handle product name validation', () => {
    const testProducts = [
      { name: 'Milch', valid: true },
      { name: 'Käse & Butter', valid: true },
      { name: '', valid: false },
      { name: 'a'.repeat(256), valid: false },
    ];

    testProducts.forEach(({ name, valid }) => {
      const product: Partial<Product> = {
        id: 1,
        name,
        quantity: 1,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(valid);
    });
  });
});

describe('Product Validation', () => {
  test('should validate quantity is a number', () => {
    const validQuantities = [100, 1.5, 0.25];
    
    validQuantities.forEach((qty) => {
      expect(typeof qty).toBe('number');
    });
  });

  test('should validate unit is a string', () => {
    const units = ['g', 'ml', 'l', 'kg', 'stck', 'pack'];
    
    units.forEach((unit) => {
      expect(typeof unit).toBe('string');
    });
  });

  test('should validate product name is not empty string', () => {
    const validNames = ['Milch', 'Butter', 'Käse', 'Öl'];
    
    validNames.forEach((name) => {
      expect(name.trim().length).toBeGreaterThan(0);
    });
  });

  test('should reject empty product names', () => {
    const emptyName = '';
    expect(emptyName.trim().length).toBe(0);
  });

  test('should trim whitespace from product names', () => {
    const nameWithSpaces = '   Milch   ';
    const trimmed = nameWithSpaces.trim();
    
    expect(trimmed).toBe('Milch');
    expect(trimmed).not.toContain('   ');
  });
});

describe('MHD and Price Validation', () => {
  test('should parse prices correctly', () => {
    const price = '1.99';
    const parsed = parseFloat(price);
    expect(parsed).toBe(1.99);
  });

  test('should handle MHD dates with valid format', () => {
    const mhd = '2024-04-01';
    expect(mhd).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  test('should validate MHD date format fails for invalid dates', () => {
    const invalidMhd = '01-04-2024';
    expect(invalidMhd).not.toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  test('should handle multiple date formats separately', () => {
    const isoFormat = '2024-12-31';
    const invalidFormat = '31/12/2024';
    
    expect(isoFormat).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(invalidFormat).not.toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  test('should parse zero price', () => {
    const zeroPrice = '0.00';
    expect(parseFloat(zeroPrice)).toBe(0);
  });

  test('should parse prices with multiple decimal places', () => {
    const prices = ['1.99', '10.50', '0.01', '100.00'];
    
    prices.forEach((price) => {
      const parsed = parseFloat(price);
      expect(parsed).toBeDefined();
      expect(typeof parsed).toBe('number');
    });
  });
});

describe('Collection Operations', () => {
  test('should handle empty product array', () => {
    const products = [];
    expect(Array.isArray(products)).toBe(true);
    expect(products.length).toBe(0);
  });

  test('should handle products array with multiple items', () => {
    const products = [
      { id: 1, name: 'Milch', quantity: 1, unit: 'l' },
      { id: 2, name: 'Butter', quantity: 250, unit: 'g' },
      { id: 3, name: 'Käse', quantity: 200, unit: 'g' },
    ];

    expect(Array.isArray(products)).toBe(true);
    expect(products.length).toBe(3);
  });

  test('should validate all products in array have required fields', () => {
    const products = [
      { id: 1, name: 'Item1', quantity: 100, unit: 'g' },
      { id: 2, name: 'Item2', quantity: 200, unit: 'ml' },
    ];

    products.forEach((product) => {
      expect(product).toHaveProperty('id');
      expect(product).toHaveProperty('name');
      expect(product).toHaveProperty('quantity');
      expect(product).toHaveProperty('unit');
    });
  });

  test('should sort products by MHD', () => {
    const products = [
      { id: 1, name: 'A', mhd: '2024-12-31' },
      { id: 2, name: 'B', mhd: '2024-10-15' },
      { id: 3, name: 'C', mhd: '2024-11-20' },
    ];

    const sorted = [...products].sort((a, b) => 
      new Date(a.mhd).getTime() - new Date(b.mhd).getTime()
    );

    expect(sorted[0].id).toBe(2);
    expect(sorted[1].id).toBe(3);
    expect(sorted[2].id).toBe(1);
  });

  test('should sort products by name', () => {
    const products = [
      { id: 1, name: 'Zebra' },
      { id: 2, name: 'Apple' },
      { id: 3, name: 'Banana' },
    ];

    const sorted = [...products].sort((a, b) => a.name.localeCompare(b.name));

    expect(sorted[0].name).toBe('Apple');
    expect(sorted[1].name).toBe('Banana');
    expect(sorted[2].name).toBe('Zebra');
  });

  test('should filter products by search term', () => {
    const products = [
      { id: 1, name: 'Milch' },
      { id: 2, name: 'Butter' },
      { id: 3, name: 'Käse' },
    ];

    const filtered = products.filter((p) =>
      p.name.toLowerCase().includes('milch')
    );

    expect(filtered).toHaveLength(1);
    expect(filtered[0].id).toBe(1);
  });
});
