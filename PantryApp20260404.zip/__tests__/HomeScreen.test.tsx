import { Product } from '../src/types/product';

describe('HomeScreen Logic', () => {
  const mockProducts: Product[] = [
    {
      id: 1,
      name: 'Milch',
      quantity: 1,
      unit: 'l',
      mhd: '2024-12-31',
      price: 1.99,
      created_at: '2024-10-01',
      updated_at: '2024-10-01',
    },
    {
      id: 2,
      name: 'Butter',
      quantity: 250,
      unit: 'g',
      mhd: '2024-12-25',
      price: 3.99,
      created_at: '2024-10-02',
      updated_at: '2024-10-02',
    },
    {
      id: 3,
      name: 'Apfel',
      quantity: 5,
      unit: 'Stück',
      mhd: '2024-10-15',
      price: 0.99,
      created_at: '2024-10-03',
      updated_at: '2024-10-03',
    },
  ];

  describe('Product Filtering', () => {
    test('should filter products by search term', () => {
      const searchTerm = 'milch';
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      expect(filtered).toHaveLength(1);
      expect(filtered[0].id).toBe(1);
    });

    test('should filter with case-insensitive search', () => {
      const searchTerm = 'MILCH';
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      expect(filtered).toHaveLength(1);
    });

    test('should return empty array for non-matching search', () => {
      const searchTerm = 'xyz';
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      expect(filtered).toHaveLength(0);
    });

    test('should filter products with partial match', () => {
      const searchTerm = 'ap';
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      expect(filtered).toHaveLength(1); // Only Apfel contains "ap"
    });
  });

  describe('Product Sorting', () => {
    test('should sort products by name', () => {
      const sorted = [...mockProducts].sort((a, b) =>
        a.name.localeCompare(b.name)
      );

      expect(sorted[0].name).toBe('Apfel');
      expect(sorted[1].name).toBe('Butter');
      expect(sorted[2].name).toBe('Milch');
    });

    test('should sort products by MHD date', () => {
      const sorted = [...mockProducts].sort((a, b) => {
        if (!a.mhd) return 1;
        if (!b.mhd) return -1;
        return new Date(a.mhd).getTime() - new Date(b.mhd).getTime();
      });

      expect(sorted[0].id).toBe(3); // Apfel 2024-10-15
      expect(sorted[1].id).toBe(2); // Butter 2024-12-25
      expect(sorted[2].id).toBe(1); // Milch 2024-12-31
    });

    test('should sort products by price (descending)', () => {
      const sorted = [...mockProducts].sort((a, b) =>
        (b.price || 0) - (a.price || 0)
      );

      expect(sorted[0].price).toBe(3.99);
      expect(sorted[1].price).toBe(1.99);
      expect(sorted[2].price).toBe(0.99);
    });

    test('should handle products without MHD in sorting', () => {
      const productsWithoutMhd = [
        { ...mockProducts[0], mhd: undefined },
        mockProducts[1],
      ];

      const sorted = [...productsWithoutMhd].sort((a, b) => {
        if (!a.mhd) return 1;
        if (!b.mhd) return -1;
        return new Date(a.mhd).getTime() - new Date(b.mhd).getTime();
      });

      expect(sorted[0].mhd).toBe('2024-12-25');
      expect(sorted[1].mhd).toBeUndefined();
    });

    test('should handle sort with same MHD dates', () => {
      const productsWithSameMhd = [
        { ...mockProducts[0], mhd: '2024-12-31' },
        { ...mockProducts[1], mhd: '2024-12-31' },
        mockProducts[2],
      ];

      const sorted = [...productsWithSameMhd].sort((a, b) => {
        if (!a.mhd) return 1;
        if (!b.mhd) return -1;
        return new Date(a.mhd).getTime() - new Date(b.mhd).getTime();
      });

      expect(sorted[2].mhd).toBe('2024-12-31'); // Last item should have earliest MHD or same
    });
  });

  describe('Product Count and Display', () => {
    test('should handle empty product list', () => {
      const products: Product[] = [];

      expect(products).toHaveLength(0);
    });

    test('should display all products on first load', () => {
      expect(mockProducts).toHaveLength(3);
    });

    test('should maintain product data integrity after filter', () => {
      const filtered = mockProducts.filter((p) => p.price! > 1);

      filtered.forEach((product) => {
        expect(product).toHaveProperty('id');
        expect(product).toHaveProperty('name');
        expect(product).toHaveProperty('quantity');
      });
    });
  });

  describe('Delete Product Logic', () => {
    test('should handle product deletion from list', () => {
      const products = [...mockProducts];
      const idToDelete = 1;
      const remaining = products.filter((p) => p.id !== idToDelete);

      expect(remaining).toHaveLength(2);
      expect(remaining[0].id).not.toBe(1);
    });

    test('should handle delete of non-existent product', () => {
      const products = [...mockProducts];
      const idToDelete = 999;
      const remaining = products.filter((p) => p.id !== idToDelete);

      expect(remaining).toHaveLength(3); // No change
    });
  });

  describe('Search and Sort Combination', () => {
    test('should maintain search text when sorting changes', () => {
      const searchText = 'butter';
      const sortType = 'name';

      let filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchText.toLowerCase())
      );

      expect(filtered).toHaveLength(1);
      expect(filtered[0].name).toBe('Butter');

      // Sort should still apply to filtered results
      filtered = filtered.sort((a, b) => a.name.localeCompare(b.name));
      expect(filtered[0].name).toBe('Butter');
    });

    test('should filter before sorting', () => {
      const searchText = 'a';
      let filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchText.toLowerCase())
      );

      filtered = filtered.sort((a, b) => a.name.localeCompare(b.name));

      expect(filtered).toHaveLength(1); // Only Apfel contains "a"
      expect(filtered[0].name).toBe('Apfel');
    });
  });
});
