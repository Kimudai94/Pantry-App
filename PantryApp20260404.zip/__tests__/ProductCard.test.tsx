import { Product } from '../src/types/product';
import { getMhdStatus } from '../src/utils/mhdStatus';

describe('ProductCard Component', () => {
  const mockProduct: Product = {
    id: 1,
    name: 'Milch',
    quantity: 1,
    unit: 'l',
    mhd: '2024-12-31',
    price: 1.99,
  };

  describe('getMhdStatus integration', () => {
    test('should use getMhdStatus utility correctly', () => {
      const result = getMhdStatus(mockProduct.mhd);
      
      expect(result).toHaveProperty('type');
      expect(result).toHaveProperty('text');
    });

    test('should handle undefined MHD from product', () => {
      const product = { ...mockProduct, mhd: undefined };
      const result = getMhdStatus(product.mhd);
      
      expect(result.type).toBe('none');
      expect(result.text).toBe('MHD nicht angegeben');
    });

    test('should display correct status for expired product', () => {
      const expiredProduct = { ...mockProduct, mhd: '2020-01-01' };
      const result = getMhdStatus(expiredProduct.mhd);
      
      expect(result.type).toBe('expired');
      expect(result.text).toContain('❌');
    });

    test('should display correct status for warning product', () => {
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];
      
      const warningProduct = { ...mockProduct, mhd: tomorrowStr };
      const result = getMhdStatus(warningProduct.mhd, today);
      
      expect(result.type).toBe('warning');
      expect(result.text).toContain('⚠️');
    });

    test('should display correct status for ok product', () => {
      const today = new Date();
      const in30Days = new Date(today);
      in30Days.setDate(in30Days.getDate() + 30);
      const in30DaysStr = in30Days.toISOString().split('T')[0];
      
      const okProduct = { ...mockProduct, mhd: in30DaysStr };
      const result = getMhdStatus(okProduct.mhd, today);
      
      expect(result.type).toBe('ok');
      expect(result.text).toContain('✅');
    });
  });

  describe('Product Card Display Logic', () => {
    test('should display product name correctly', () => {
      const { name } = mockProduct;
      
      expect(name).toBeTruthy();
      expect(name).toBe('Milch');
    });

    test('should display quantity with unit', () => {
      const display = `${mockProduct.quantity} ${mockProduct.unit}`;
      
      expect(display).toBe('1 l');
    });

    test('should format price with 2 decimal places', () => {
      const formatted = mockProduct.price?.toFixed(2);
      
      expect(formatted).toBe('1.99');
    });

    test('should handle price display as currency', () => {
      if (mockProduct.price) {
        const displayPrice = `${mockProduct.price.toFixed(2)} €`;
        expect(displayPrice).toBe('1.99 €');
      }
    });

    test('should not display price when undefined', () => {
      const productWithoutPrice = { ...mockProduct, price: undefined };
      
      expect(productWithoutPrice.price).toBeUndefined();
    });

    test('should handle products with various units', () => {
      const variants = [
        { ...mockProduct, unit: 'g' },
        { ...mockProduct, unit: 'ml' },
        { ...mockProduct, unit: 'Stück' },
        { ...mockProduct, unit: 'kg' },
      ];

      variants.forEach((product) => {
        expect(product.unit).toBeTruthy();
        const display = `${product.quantity} ${product.unit}`;
        expect(display).toContain(product.unit);
      });
    });

    test('should handle large quantities', () => {
      const largeQtyProduct = { ...mockProduct, quantity: 9999.99 };
      
      expect(largeQtyProduct.quantity).toBeGreaterThan(1000);
    });

    test('should handle very long product names', () => {
      const longName = 'Dieses ist ein sehr langer Produktname für Testzwecke';
      const longProduct = { ...mockProduct, name: longName };
      
      expect(longProduct.name.length).toBeGreaterThan(30);
    });

    test('should handle zero quantity', () => {
      const zeroQtyProduct = { ...mockProduct, quantity: 0 };
      
      expect(zeroQtyProduct.quantity).toBe(0);
    });

    test('should handle high prices', () => {
      const expensiveProduct = { ...mockProduct, price: 999.99 };
      const formatted = expensiveProduct.price.toFixed(2);
      
      expect(formatted).toBe('999.99');
    });

    test('should handle low prices', () => {
      const cheapProduct = { ...mockProduct, price: 0.01 };
      const formatted = cheapProduct.price.toFixed(2);
      
      expect(formatted).toBe('0.01');
    });
  });

  describe('Product properties validation', () => {
    test('should have all required fields', () => {
      const requiredFields = ['id', 'name', 'quantity', 'unit'] as const;
      
      requiredFields.forEach((field) => {
        expect(mockProduct).toHaveProperty(field);
      });
    });

    test('should have optional price field', () => {
      expect(mockProduct).toHaveProperty('price');
    });

    test('should have optional MHD field', () => {
      expect(mockProduct).toHaveProperty('mhd');
    });

    test('should validate product name is string', () => {
      expect(typeof mockProduct.name).toBe('string');
    });

    test('should validate quantity is number', () => {
      expect(typeof mockProduct.quantity).toBe('number');
    });

    test('should validate unit is string', () => {
      expect(typeof mockProduct.unit).toBe('string');
    });
  });

  describe('Callback handlers', () => {
    test('should call onEdit callback when edit button pressed', () => {
      const onEdit = jest.fn();
      
      onEdit();
      
      expect(onEdit).toHaveBeenCalledTimes(1);
    });

    test('should call onDelete callback when delete button pressed', () => {
      const onDelete = jest.fn();
      
      onDelete();
      
      expect(onDelete).toHaveBeenCalledTimes(1);
    });

    test('should handle multiple quick edit calls', () => {
      const onEdit = jest.fn();
      
      onEdit();
      onEdit();
      onEdit();
      
      expect(onEdit).toHaveBeenCalledTimes(3);
    });

    test('should handle multiple quick delete calls', () => {
      const onDelete = jest.fn();
      
      onDelete();
      onDelete();
      
      expect(onDelete).toHaveBeenCalledTimes(2);
    });

    test('should handle both callbacks independently', () => {
      const onEdit = jest.fn();
      const onDelete = jest.fn();
      
      onEdit();
      onDelete();
      onEdit();
      
      expect(onEdit).toHaveBeenCalledTimes(2);
      expect(onDelete).toHaveBeenCalledTimes(1);
    });
  });

  describe('MHD Status Variations', () => {
    test('should handle product with future MHD', () => {
      const futureDate = '2099-12-31';
      const product = { ...mockProduct, mhd: futureDate };
      const result = getMhdStatus(product.mhd);
      
      expect(result.type).toBe('ok');
    });

    test('should handle product with past MHD', () => {
      const pastDate = '2000-01-01';
      const product = { ...mockProduct, mhd: pastDate };
      const result = getMhdStatus(product.mhd);
      
      expect(result.type).toBe('expired');
    });

    test('should handle product with no MHD', () => {
      const product = { ...mockProduct, mhd: undefined };
      const result = getMhdStatus(product.mhd);
      
      expect(result.type).toBe('none');
    });

    test('should handle product with invalid MHD', () => {
      const product = { ...mockProduct, mhd: 'invalid-date' };
      const result = getMhdStatus(product.mhd);
      
      expect(result.type).toBe('none');
    });

    test('should show correct emoji for each status', () => {
      const testCases = [
        { mhd: undefined, emoji: '' }, // none
        { mhd: '2000-01-01', emoji: '❌' }, // expired
        { mhd: '2099-12-31', emoji: '✅' }, // ok
      ];

      testCases.forEach(({ mhd, emoji }) => {
        const result = getMhdStatus(mhd);
        if (emoji) {
          expect(result.text).toContain(emoji);
        }
      });
    });
  });

  describe('Product variants', () => {
    test('should handle product with decimal quantity', () => {
      const fractionalProduct = { ...mockProduct, quantity: 2.5, unit: 'kg' };
      
      expect(fractionalProduct.quantity).toBe(2.5);
    });

    test('should handle product without price', () => {
      const product = { ...mockProduct, price: undefined };
      
      expect(product.price).toBeUndefined();
    });

    test('should handle different product ids', () => {
      const products = [
        { ...mockProduct, id: 1 },
        { ...mockProduct, id: 100 },
        { ...mockProduct, id: 999999 },
      ];

      products.forEach((product) => {
        expect(product.id).toBeGreaterThan(0);
      });
    });
  });
});
