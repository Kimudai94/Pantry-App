import { Product } from '../src/types/product';
import { filterAndSortProducts, searchProducts, sortProducts } from '../src/utils/productFilter';

describe('Product Filter & Sort Utilities', () => {
  const mockProducts: Product[] = [
    {
      id: 1,
      name: 'Milch',
      quantity: 1,
      unit: 'l',
      mhd: '2024-12-31',
      price: 1.99,
    },
    {
      id: 2,
      name: 'Butter',
      quantity: 250,
      unit: 'g',
      mhd: '2024-12-25',
      price: 3.99,
    },
    {
      id: 3,
      name: 'Apfel',
      quantity: 5,
      unit: 'Stück',
      mhd: '2024-10-15',
      price: 0.99,
    },
    {
      id: 4,
      name: 'Käse',
      quantity: 200,
      unit: 'g',
      mhd: undefined,
      price: 2.50,
    },
  ];

  describe('searchProducts()', () => {
    test('should filter products by exact name match', () => {
      const results = searchProducts(mockProducts, 'Milch');
      expect(results).toHaveLength(1);
      expect(results[0].id).toBe(1);
    });

    test('should filter products by partial name match', () => {
      const results = searchProducts(mockProducts, 'ap');
      expect(results).toHaveLength(1); // Only Apfel contains "ap"
      expect(results.some(p => p.name === 'Apfel')).toBe(true);
    });

    test('should perform case-insensitive search', () => {
      const results1 = searchProducts(mockProducts, 'MILCH');
      const results2 = searchProducts(mockProducts, 'milch');
      const results3 = searchProducts(mockProducts, 'Milch');

      expect(results1).toHaveLength(1);
      expect(results2).toHaveLength(1);
      expect(results3).toHaveLength(1);
      expect(results1[0].id).toBe(results2[0].id);
    });

    test('should return empty array when no match', () => {
      const results = searchProducts(mockProducts, 'xyz');
      expect(results).toHaveLength(0);
    });

    test('should return all products for empty search', () => {
      const results = searchProducts(mockProducts, '');
      expect(results).toHaveLength(4);
    });
  });

  describe('sortProducts()', () => {
    test('should sort products by name', () => {
      const results = sortProducts(mockProducts, 'name');
      expect(results[0].name).toBe('Apfel');
      expect(results[1].name).toBe('Butter');
      expect(results[2].name).toBe('Käse');
      expect(results[3].name).toBe('Milch');
    });

    test('should sort products by MHD date', () => {
      const results = sortProducts(mockProducts, 'mhd');
      expect(results[0].id).toBe(3); // 2024-10-15
      expect(results[1].id).toBe(2); // 2024-12-25
      expect(results[2].id).toBe(1); // 2024-12-31
      expect(results[3].id).toBe(4); // undefined (last)
    });

    test('should sort products by price descending', () => {
      const results = sortProducts(mockProducts, 'price');
      expect(results[0].price).toBe(3.99); // Butter
      expect(results[1].price).toBe(2.50); // Käse
      expect(results[2].price).toBe(1.99); // Milch
      expect(results[3].price).toBe(0.99); // Apfel
    });

    test('should handle products without MHD', () => {
      const results = sortProducts(mockProducts, 'mhd');
      // Products without MHD should be at the end
      expect(results[results.length - 1].id).toBe(4);
      expect(results[results.length - 1].mhd).toBeUndefined();
    });

    test('should default to mhd sort when type is invalid', () => {
      const results = sortProducts(mockProducts, 'invalid' as any);
      // Should still return sorted array (default behavior)
      expect(results).toHaveLength(4);
    });
  });

  describe('filterAndSortProducts()', () => {
    test('should filter and sort by name', () => {
      const results = filterAndSortProducts(mockProducts, 'a', 'name');
      // Products containing 'a': Apfel, Käse, Milch (all have 'a' when case-insensitive)
      expect(results.length).toBeGreaterThan(0);
      expect(results.some(p => p.name === 'Apfel')).toBe(true);
    });

    test('should filter and sort by MHD', () => {
      const results = filterAndSortProducts(mockProducts, 'butter', 'mhd');
      expect(results).toHaveLength(1);
      expect(results[0].id).toBe(2);
      expect(results[0].mhd).toBe('2024-12-25');
    });

    test('should filter and sort by price', () => {
      const results = filterAndSortProducts(mockProducts, '', 'price');
      // All products sorted by price descending
      expect(results).toHaveLength(4);
      expect(results[0].price).toBe(3.99);
      expect(results[results.length - 1].price).toBe(0.99);
    });

    test('should handle filter with no results then sort', () => {
      const results = filterAndSortProducts(mockProducts, 'nonexistent', 'name');
      expect(results).toHaveLength(0);
    });

    test('should maintain case-insensitive search with sort', () => {
      const results1 = filterAndSortProducts(mockProducts, 'MILCH', 'name');
      const results2 = filterAndSortProducts(mockProducts, 'milch', 'name');

      expect(results1).toHaveLength(1);
      expect(results2).toHaveLength(1);
      expect(results1[0].id).toBe(results2[0].id);
    });

    test('should not modify original array', () => {
      const originalLength = mockProducts.length;
      filterAndSortProducts(mockProducts, 'a', 'name');
      expect(mockProducts).toHaveLength(originalLength);
    });

    test('should handle empty product array', () => {
      const results = filterAndSortProducts([], 'search', 'name');
      expect(results).toHaveLength(0);
    });

    test('should handle empty search string', () => {
      const results = filterAndSortProducts(mockProducts, '', 'name');
      expect(results).toHaveLength(4);
    });
  });

  describe('Complex scenarios', () => {
    test('should search for "ä" (special character)', () => {
      const results = searchProducts(mockProducts, 'ä');
      expect(results).toHaveLength(1);
      expect(results[0].name).toBe('Käse');
    });

    test('should handle multiple products with same price', () => {
      const testProducts = [
        { ...mockProducts[0], price: 2.00 },
        { ...mockProducts[1], price: 2.00 },
        mockProducts[2],
      ];

      const results = sortProducts(testProducts, 'price');
      // Both with 2.00 should be before 0.99
      expect(results[results.length - 1].price).toBe(0.99);
    });

    test('should handle filter -> sort -> filter pattern', () => {
      let results = filterAndSortProducts(mockProducts, 'a', 'name');
      expect(results.length).toBeGreaterThan(0);

      // Re-filter with different term
      results = filterAndSortProducts(mockProducts, 'butter', 'mhd');
      expect(results).toHaveLength(1);
    });

    test('should handle sorting after filtering all but one', () => {
      const results = filterAndSortProducts(mockProducts, 'milch', 'price');
      expect(results).toHaveLength(1);
      expect(results[0].id).toBe(1);
    });
  });
});
