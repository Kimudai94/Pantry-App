/**
 * Integration Tests für Pantry-App
 * Testplan: INT-001 bis INT-009
 * 
 * Diese Tests validieren das Zusammenspiel mehrerer Module:
 * - Product Type
 * - Database operations
 * - MHD-Status Utility
 * - Screen Logic (HomeScreen, ProductCard)
 */

import { Product } from '../src/types/product';
import { getMhdStatus } from '../src/utils/mhdStatus';

describe('Integration Tests: Product Lifecycle & Data Management', () => {
  /**
   * INT-001: Product Lifecycle Integration
   * Workflow: Add → Show → Edit → Delete
   * 
   * Testplan: Ein Produkt wird hinzugefügt, angezeigt, bearbeitet und gelöscht
   */
  describe('INT-001: Product Lifecycle (Add → Edit → Delete)', () => {
    test('INT-001-1: Should complete full product lifecycle', () => {
      // Step 1: Create new product (simulated Add)
      const newProduct: Product = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: '2024-12-31',
        price: 2.99,
        created_at: new Date().toISOString(),
      };

      // Step 2: Verify product exists (simulated HomeScreen display)
      expect(newProduct.name).toBe('Milch');
      expect(newProduct.quantity).toBe(1);
      expect(newProduct.id).toBe(1);

      // Step 3: Edit product (simulated EditScreen)
      const editedProduct: Product = {
        ...newProduct,
        quantity: 2, // Change quantity 1L → 2L
        updated_at: new Date().toISOString(),
      };

      // Step 4: Verify product was edited
      expect(editedProduct.quantity).toBe(2);
      expect(editedProduct.name).toBe('Milch');
      expect(editedProduct.id).toBe(1);

      // Step 5: Delete product (simulated delete)
      const products = [editedProduct];
      const filteredProducts = products.filter((p) => p.id !== 1);

      // Step 6: Verify product was deleted
      expect(filteredProducts).toHaveLength(0);
    });

    test('INT-001-2: MHD-Status should be integrated during lifecycle', () => {
      // Use date 30 days from now (should always be OK)
      const today = new Date();
      const in30Days = new Date(today);
      in30Days.setDate(in30Days.getDate() + 30);
      const dateStr = in30Days.toISOString().split('T')[0];

      const product: Product = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: dateStr,
        price: 2.99,
      };

      // When displaying product, MHD-Status is calculated
      const mhdStatus = getMhdStatus(product.mhd);

      // Verify status is OK (far in future)
      expect(mhdStatus.type).toBe('ok');
      expect(mhdStatus.text).toContain('✅');
    });
  });

  /**
   * INT-002: Multiple Products Management
   * Testplan: Mehrere Produkte hinzufügen, anzeigen, können alle verwaltet werden
   */
  describe('INT-002: Multiple Products Management', () => {
    const createMockProducts = (): Product[] => [
      {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: '2025-12-31',
        price: 2.99,
      },
      {
        id: 2,
        name: 'Brot',
        quantity: 1,
        unit: 'Stück',
        mhd: '2025-01-02',
        price: 3.50,
      },
      {
        id: 3,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
        mhd: '2025-01-08',
        price: 5.99,
      },
    ];

    test('INT-002-1: Should display all products on HomeScreen', () => {
      const products = createMockProducts();

      // Verify all products are displayed
      expect(products).toHaveLength(3);
      expect(products[0].name).toBe('Milch');
      expect(products[1].name).toBe('Brot');
      expect(products[2].name).toBe('Butter');
    });

    test('INT-002-2: All products should be filterable', () => {
      const products = createMockProducts();
      const searchTerm = 'butter';

      // Simulate search functionality
      const filtered = products.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      // Verify search works
      expect(filtered).toHaveLength(1);
      expect(filtered[0].name).toBe('Butter');
    });

    test('INT-002-3: All products should be sortable', () => {
      const products = createMockProducts();

      // Sort by name A-Z
      const sorted = [...products].sort((a, b) =>
        a.name.localeCompare(b.name)
      );

      // Verify sorting: Brot, Butter, Milch
      expect(sorted[0].name).toBe('Brot');
      expect(sorted[1].name).toBe('Butter');
      expect(sorted[2].name).toBe('Milch');
    });
  });

  /**
   * INT-003: Complex Operations on Multiple Products
   * Testplan: Add + Edit + Delete auf mehrere Products sollte alle funktionieren
   */
  describe('INT-003: Complex Multi-Product Operations', () => {
    test('INT-003-1: Should handle add, edit, and delete on multiple products', () => {
      let products: Product[] = [];

      // Step 1: Add 3 products
      const product1: Product = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        price: 2.99,
      };
      const product2: Product = {
        id: 2,
        name: 'Brot',
        quantity: 1,
        unit: 'Stück',
        price: 3.50,
      };
      const product3: Product = {
        id: 3,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
        price: 5.99,
      };

      products = [product1, product2, product3];
      expect(products).toHaveLength(3);

      // Step 2: Edit product 1
      products = products.map((p) =>
        p.id === 1 ? { ...p, quantity: 2 } : p
      );
      expect(products[0].quantity).toBe(2);

      // Step 3: Delete product 2
      products = products.filter((p) => p.id !== 2);
      expect(products).toHaveLength(2);

      // Step 4: Verify final state
      expect(products.map((p) => p.name)).toEqual(['Milch', 'Butter']);
    });

    test('INT-003-2: Should maintain data integrity through operations', () => {
      const products1 = [
        { id: 1, name: 'Product A', quantity: 1, unit: 'l' },
        { id: 2, name: 'Product B', quantity: 2, unit: 'g' },
      ];

      // Add product
      const products2 = [
        ...products1,
        { id: 3, name: 'Product C', quantity: 3, unit: 'kg' },
      ];
      expect(products2).toHaveLength(3);

      // Edit product 1
      const products3 = products2.map((p) =>
        p.id === 1 ? { ...p, quantity: 10 } : p
      );
      expect(products3[0].quantity).toBe(10);

      // Delete product 3
      const products4 = products3.filter((p) => p.id !== 3);
      expect(products4).toHaveLength(2);

      // Verify integrity
      expect(products4[0].id).toBe(1);
      expect(products4[0].quantity).toBe(10);
      expect(products4[1].id).toBe(2);
    });
  });

  /**
   * INT-004: Data Persistence
   * Testplan: Daten sollten nach App-Neustart erhalten bleiben (via Mock-Storage)
   */
  describe('INT-004: Data Persistence Simulation', () => {
    test('INT-004-1: Should persist products in mock storage', () => {
      const mockStorage: Record<string, string> = {};

      // Simulate adding products
      const products: Product[] = [
        { id: 1, name: 'Milch', quantity: 1, unit: 'l' },
        { id: 2, name: 'Brot', quantity: 1, unit: 'Stück' },
      ];

      // Simulate storing to mock database
      mockStorage['products'] = JSON.stringify(products);
      expect(mockStorage['products']).toBeDefined();

      // Simulate app restart - retrieve from storage
      const storedProducts = JSON.parse(mockStorage['products']) as Product[];

      // Verify data was preserved
      expect(storedProducts).toHaveLength(2);
      expect(storedProducts[0].name).toBe('Milch');
      expect(storedProducts[1].name).toBe('Brot');
    });

    test('INT-004-2: Should handle large dataset persistence', () => {
      const mockStorage: Record<string, string> = {};

      // Simulate adding 100 products
      const largeDataset = Array.from({ length: 100 }, (_, i) => ({
        id: i + 1,
        name: `Product ${i + 1}`,
        quantity: Math.random() * 100,
        unit: ['g', 'ml', 'l', 'kg', 'Stück'][i % 5],
      }));

      mockStorage['products'] = JSON.stringify(largeDataset);

      // Simulate app restart
      const retrieved = JSON.parse(mockStorage['products']) as Product[];

      // Verify all products retrieved
      expect(retrieved).toHaveLength(100);
      expect(retrieved[0].name).toBe('Product 1');
      expect(retrieved[99].name).toBe('Product 100');
    });
  });

  /**
   * INT-005: Changes Persistence
   * Testplan: Bearbeitungen sollten dauerhaft gespeichert werden
   */
  describe('INT-005: Changes Persistence', () => {
    test('INT-005-1: Modified products should persist after save', () => {
      const mockStorage: Record<string, string> = {};

      // Initial data
      const initialProducts: Product[] = [
        { id: 1, name: 'Milch', quantity: 1, unit: 'l', price: 2.99 },
      ];
      mockStorage['products'] = JSON.stringify(initialProducts);

      // Simulate edit in app
      const products = JSON.parse(
        mockStorage['products']
      ) as Product[];
      const edited = products.map((p) =>
        p.id === 1 ? { ...p, quantity: 2 } : p
      );

      // Save changes
      mockStorage['products'] = JSON.stringify(edited);

      // Simulate app restart - verify changes persisted
      const afterRestart = JSON.parse(
        mockStorage['products']
      ) as Product[];
      expect(afterRestart[0].quantity).toBe(2);
      expect(afterRestart[0].name).toBe('Milch'); // Other fields unchanged
    });

    test('INT-005-2: Multiple edits should accumulate', () => {
      const mockStorage: Record<string, string> = {};
      const products: Product[] = [
        { id: 1, name: 'Product', quantity: 1, unit: 'l' },
      ];

      mockStorage['products'] = JSON.stringify(products);

      // Edit 1: Change quantity
      let current = JSON.parse(mockStorage['products']) as Product[];
      current = current.map((p) =>
        p.id === 1 ? { ...p, quantity: 2 } : p
      );
      mockStorage['products'] = JSON.stringify(current);

      // Edit 2: Change name
      current = JSON.parse(mockStorage['products']) as Product[];
      current = current.map((p) =>
        p.id === 1 ? { ...p, name: 'Updated' } : p
      );
      mockStorage['products'] = JSON.stringify(current);

      // Verify both changes persisted
      const final = JSON.parse(mockStorage['products']) as Product[];
      expect(final[0].quantity).toBe(2);
      expect(final[0].name).toBe('Updated');
    });
  });

  /**
   * INT-006: MHD-Status Display Integration
   * Testplan: Bei Product-Anzeige wird MHD-Status korrekt berechnet
   */
  describe('INT-006: MHD-Status Display Integration', () => {
    test('INT-006-1: Warning status should display with product', () => {
      // Create product with MHD a few days from now
      const today = new Date();
      const in3Days = new Date(today);
      in3Days.setDate(in3Days.getDate() + 3);
      const dateStr = in3Days.toISOString().split('T')[0];

      const product: Product = {
        id: 1,
        name: 'Brot',
        quantity: 1,
        unit: 'Stück',
        mhd: dateStr,
        price: 3.50,
      };

      // In HomeScreen: Get MHD-Status when displaying
      const mhdStatus = getMhdStatus(product.mhd, today);

      // Verify warning status
      expect(mhdStatus.type).toBe('warning');
      expect(mhdStatus.text).toContain('⚠️');
      // Status should mention Tage (days)
      expect(mhdStatus.text).toMatch(/Tage/);
    });

    test('INT-006-2: OK status should display with product far in future', () => {
      // Use date 30 days from now
      const today = new Date();
      const in30Days = new Date(today);
      in30Days.setDate(in30Days.getDate() + 30);
      const dateStr = in30Days.toISOString().split('T')[0];

      const product: Product = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: dateStr,
        price: 2.99,
      };

      // Get status when displaying
      const mhdStatus = getMhdStatus(product.mhd);

      // Verify OK status
      expect(mhdStatus.type).toBe('ok');
      expect(mhdStatus.text).toContain('✅');
    });

    test('INT-006-3: Expired status should display with urgent styling', () => {
      const product: Product = {
        id: 1,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
        mhd: '2020-01-01',
        price: 5.99,
      };

      // Get status when displaying
      const mhdStatus = getMhdStatus(product.mhd);

      // Verify expired status
      expect(mhdStatus.type).toBe('expired');
      expect(mhdStatus.text).toContain('❌');
    });
  });

  /**
   * INT-007: MHD-Status Changes Over Time
   * Testplan: Status sollte sich updaten wenn Zeit vergeht
   */
  describe('INT-007: MHD-Status Timeline Integration', () => {
    test('INT-007-1: Status should transition from OK to Warning', () => {
      const product: Product = {
        id: 1,
        name: 'Product',
        quantity: 1,
        unit: 'l',
        mhd: '2026-02-01', // Exactly 9 days from Jan 23, 2026
      };

      // Day 1: Status should be OK (>7 days)
      const today1 = new Date('2026-01-23');
      const status1 = getMhdStatus(product.mhd, today1);
      expect(status1.type).toBe('ok');

      // Day 8: Status should be WARNING (≤7 days)
      const today2 = new Date('2026-01-26');
      const status2 = getMhdStatus(product.mhd, today2);
      expect(status2.type).toBe('warning');
    });

    test('INT-007-2: Status should transition from Warning to Expired', () => {
      const product: Product = {
        id: 1,
        name: 'Product',
        quantity: 1,
        unit: 'l',
        mhd: '2026-01-23',
      };

      // 1 day before: WARNING
      const dayBefore = new Date('2026-01-22');
      const statusWarning = getMhdStatus(product.mhd, dayBefore);
      expect(statusWarning.type).toBe('warning');

      // Day after: EXPIRED
      const dayAfter = new Date('2026-01-24');
      const statusExpired = getMhdStatus(product.mhd, dayAfter);
      expect(statusExpired.type).toBe('expired');
    });

    test('INT-007-3: Multiple products should update correctly', () => {
      const products: Product[] = [
        { id: 1, name: 'A', quantity: 1, unit: 'l', mhd: '2026-01-23' },
        { id: 2, name: 'B', quantity: 1, unit: 'l', mhd: '2026-02-01' },
        { id: 3, name: 'C', quantity: 1, unit: 'l', mhd: '2020-01-01' },
      ];

      const today = new Date('2026-01-23');

      const statuses = products.map((p) => ({
        id: p.id,
        status: getMhdStatus(p.mhd, today),
      }));

      // Verify each product has correct status
      expect(statuses[0].status.type).toBe('warning'); // Today = warning
      expect(statuses[1].status.type).toBe('ok'); // 9 days = OK
      expect(statuses[2].status.type).toBe('expired'); // Past date = expired
    });
  });

  /**
   * INT-008: Search & Filter Combined Operations
   * Testplan: Suche und Sortierung sollten zusammen funktionieren
   */
  describe('INT-008: Search & Filter Combination', () => {
    const mockProducts: Product[] = [
      { id: 1, name: 'Apfel', quantity: 5, unit: 'Stück', price: 1.99 },
      { id: 2, name: 'Paprika', quantity: 2, unit: 'Stück', price: 2.99 },
      { id: 3, name: 'Aprikose', quantity: 3, unit: 'Stück', price: 3.99 },
      { id: 4, name: 'Banane', quantity: 4, unit: 'Stück', price: 1.49 },
      { id: 5, name: 'Apfelmus', quantity: 1, unit: 'g', price: 4.99 },
    ];

    test('INT-008-1: Should filter by search term and sort by name', () => {
      const searchTerm = 'ap';

      // Filter
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      // Sort by name A-Z
      const result = [...filtered].sort((a, b) =>
        a.name.localeCompare(b.name)
      );

      // Verify: Apfel, Apfelmus, Aprikose (sorted A-Z)
      expect(result).toHaveLength(4); // Apfel, Aprikose, Apfelmus, Paprika
      expect(result[0].name).toBe('Apfel');
      expect(result[1].name).toBe('Apfelmus');
      expect(result[2].name).toBe('Aprikose');
      expect(result[3].name).toBe('Paprika');
    });

    test('INT-008-2: Should filter by search and sort descending', () => {
      const searchTerm = 'a';

      // Filter
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      // Sort by name Z-A (descending)
      const result = [...filtered].sort((a, b) =>
        b.name.localeCompare(a.name)
      );

      // Verify ordered Z-A
      expect(result[0].name).toBe('Paprika');
      expect(result[result.length - 1].name).toMatch(/^A/); // Starts with A
    });

    test('INT-008-3: Should filter empty results and handle gracefully', () => {
      const searchTerm = 'xyz';

      // Filter
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase())
      );

      // Verify no results
      expect(filtered).toHaveLength(0);
      expect(filtered.sort()).toHaveLength(0);
    });
  });

  /**
   * INT-009: Advanced Search & Sort Combinations
   * Testplan: Alle möglichen Kombinationen von Suche und Sortierung
   */
  describe('INT-009: Advanced Search + Sort Combinations', () => {
    const mockProducts: Product[] = [
      {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: '2025-02-01',
        price: 2.99,
      },
      {
        id: 2,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
        mhd: '2025-01-15',
        price: 5.99,
      },
      {
        id: 3,
        name: 'Milchschokolade',
        quantity: 100,
        unit: 'g',
        mhd: '2025-03-01',
        price: 1.99,
      },
      {
        id: 4,
        name: 'Käse',
        quantity: 200,
        unit: 'g',
        mhd: '2025-01-20',
        price: 8.99,
      },
    ];

    test('INT-009-1: Filter by "milch" + sort by name', () => {
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes('milch')
      );
      const sorted = [...filtered].sort((a, b) =>
        a.name.localeCompare(b.name)
      );

      // Should find Milch and Milchschokolade, sorted by name
      expect(sorted).toHaveLength(2);
      expect(sorted[0].name).toBe('Milch');
      expect(sorted[1].name).toBe('Milchschokolade');
    });

    test('INT-009-2: Filter by "milch" + sort by price', () => {
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes('milch')
      );
      const sorted = [...filtered].sort((a, b) => (a.price || 0) - (b.price || 0));

      // Milchschokolade (1.99) before Milch (2.99)
      expect(sorted[0].price).toBe(1.99);
      expect(sorted[1].price).toBe(2.99);
    });

    test('INT-009-3: Filter by "butter" + sort by MHD', () => {
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes('butter')
      );

      // Only one result
      expect(filtered).toHaveLength(1);
      expect(filtered[0].name).toBe('Butter');
    });

    test('INT-009-4: Case-insensitive search with multiple criteria', () => {
      // Search: case-insensitive "BUTTER", sort by price descending
      const filtered = mockProducts.filter((p) =>
        p.name.toLowerCase().includes('butter')
      );

      const sorted = [...filtered].sort((a, b) =>
        (b.price || 0) - (a.price || 0)
      );

      expect(sorted[0].name).toBe('Butter');
      expect(sorted[0].price).toBe(5.99);
    });

    test('INT-009-5: Search + sort combinations on large dataset', () => {
      // Create large dataset
      const largeDataset = Array.from({ length: 100 }, (_, i) => ({
        id: i + 1,
        name: i % 3 === 0 ? 'Product A' : `Product ${i}`,
        quantity: 1,
        unit: 'l',
        price: Math.random() * 100,
      }));

      // Filter for "Product A"
      const filtered = largeDataset.filter((p) =>
        p.name.toLowerCase().includes('product a')
      );

      // Sort by price
      const sorted = [...filtered].sort((a, b) => (a.price || 0) - (b.price || 0));

      // Verify correct filtering and sorting
      expect(filtered.length).toBeGreaterThan(0);
      expect(sorted.length).toBe(filtered.length);

      // Verify sorted correctly (ascending prices)
      for (let i = 0; i < sorted.length - 1; i++) {
        expect(sorted[i].price).toBeLessThanOrEqual(sorted[i + 1].price!);
      }
    });
  });

  /**
   * Summary of Integration Tests
   */
  test('Summary: All integration test scenarios implemented', () => {
    const testScenarios = [
      'INT-001: Product Lifecycle',
      'INT-002: Multiple Products',
      'INT-003: Complex Operations',
      'INT-004: Data Persistence',
      'INT-005: Changes Persistence',
      'INT-006: MHD-Status Display',
      'INT-007: MHD-Status Timeline',
      'INT-008: Search & Filter',
      'INT-009: Advanced Search + Sort',
    ];

    expect(testScenarios).toHaveLength(9);
    testScenarios.forEach((scenario) => {
      expect(scenario).toBeTruthy();
    });
  });
});
