import {
  validateProduct,
  validateProductName,
  validateProductQuantity,
  validateProductPrice,
  isValidMhdDate,
  ValidationResult,
} from '../src/utils/validation';
import { Product } from '../src/types/product';

describe('Product Validation Utilities', () => {
  describe('validateProduct()', () => {
    test('should validate a complete valid product', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Milch',
        quantity: 1,
        unit: 'l',
        mhd: '2024-12-31',
        price: 1.99,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should validate product with required fields only', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Butter',
        quantity: 250,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should reject product with missing name', () => {
      const product: Partial<Product> = {
        id: 1,
        quantity: 1,
        unit: 'l',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });

    test('should reject product with missing quantity', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        unit: 'l',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });

    test('should reject product with missing unit', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 1,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'unit')).toBe(true);
    });

    test('should reject product with invalid MHD', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
        mhd: 'invalid-date',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'mhd')).toBe(true);
    });

    test('should reject product with negative price', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: 1,
        unit: 'g',
        price: -1.99,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'price')).toBe(true);
    });

    test('should reject product with negative quantity', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Test',
        quantity: -5,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'quantity')).toBe(true);
    });

    test('should reject product with empty name', () => {
      const product: Partial<Product> = {
        id: 1,
        name: '   ',
        quantity: 1,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });

    test('should validate product with zero price', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'Free Sample',
        quantity: 1,
        unit: 'g',
        price: 0,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(true);
    });

    test('should reject product with name longer than 255 characters', () => {
      const product: Partial<Product> = {
        id: 1,
        name: 'a'.repeat(256),
        quantity: 1,
        unit: 'g',
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.some(e => e.field === 'name')).toBe(true);
    });
  });

  describe('validateProductName()', () => {
    test('should validate valid product name', () => {
      const result = validateProductName('Milch');
      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    test('should reject empty name', () => {
      const result = validateProductName('');
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(0);
    });

    test('should reject whitespace-only name', () => {
      const result = validateProductName('   ');
      expect(result.valid).toBe(false);
    });

    test('should reject name longer than 255 characters', () => {
      const longName = 'a'.repeat(256);
      const result = validateProductName(longName);
      expect(result.valid).toBe(false);
    });

    test('should accept special characters in name', () => {
      const result = validateProductName('Käse & Butter');
      expect(result.valid).toBe(true);
    });

    test('should validate 255 character name', () => {
      const maxName = 'a'.repeat(255);
      const result = validateProductName(maxName);
      expect(result.valid).toBe(true);
    });
  });

  describe('validateProductQuantity()', () => {
    test('should validate valid quantity as string', () => {
      const result = validateProductQuantity('100');
      expect(result.valid).toBe(true);
    });

    test('should validate valid quantity as number', () => {
      const result = validateProductQuantity(100);
      expect(result.valid).toBe(true);
    });

    test('should validate decimal quantity', () => {
      const result = validateProductQuantity('250.5');
      expect(result.valid).toBe(true);
    });

    test('should validate zero quantity', () => {
      const result = validateProductQuantity(0);
      expect(result.valid).toBe(true);
    });

    test('should reject negative quantity', () => {
      const result = validateProductQuantity('-10');
      expect(result.valid).toBe(false);
    });

    test('should reject non-numeric quantity', () => {
      const result = validateProductQuantity('abc');
      expect(result.valid).toBe(false);
    });

    test('should reject empty quantity', () => {
      const result = validateProductQuantity('');
      expect(result.valid).toBe(false);
    });

    test('should reject undefined quantity', () => {
      const result = validateProductQuantity(undefined);
      expect(result.valid).toBe(false);
    });
  });

  describe('validateProductPrice()', () => {
    test('should validate valid price as string', () => {
      const result = validateProductPrice('1.99');
      expect(result.valid).toBe(true);
    });

    test('should validate valid price as number', () => {
      const result = validateProductPrice(1.99);
      expect(result.valid).toBe(true);
    });

    test('should validate zero price', () => {
      const result = validateProductPrice(0);
      expect(result.valid).toBe(true);
    });

    test('should validate undefined price (optional)', () => {
      const result = validateProductPrice(undefined);
      expect(result.valid).toBe(true);
    });

    test('should reject negative price', () => {
      const result = validateProductPrice('-5.99');
      expect(result.valid).toBe(false);
    });

    test('should reject non-numeric price', () => {
      const result = validateProductPrice('abc');
      expect(result.valid).toBe(false);
    });

    test('should validate valid decimal price', () => {
      const result = validateProductPrice('19.99');
      expect(result.valid).toBe(true);
    });
  });

  describe('isValidMhdDate()', () => {
    test('should validate valid MHD date', () => {
      expect(isValidMhdDate('2024-12-31')).toBe(true);
    });

    test('should validate valid leap year date', () => {
      expect(isValidMhdDate('2024-02-29')).toBe(true);
    });

    test('should reject invalid date format', () => {
      expect(isValidMhdDate('31-12-2024')).toBe(false);
    });

    test('should reject invalid month', () => {
      expect(isValidMhdDate('2024-13-01')).toBe(false);
    });

    test('should reject invalid day', () => {
      expect(isValidMhdDate('2024-02-30')).toBe(false);
    });

    test('should reject empty string', () => {
      expect(isValidMhdDate('')).toBe(false);
    });

    test('should validate valid ISO date with time', () => {
      const result = isValidMhdDate('2024-12-25T10:30:00Z');
      // This should be valid as it's in ISO format
      expect(typeof result).toBe('boolean');
    });

    test('should handle different valid dates', () => {
      const validDates = [
        '2024-01-01',
        '2024-06-15',
        '2024-12-31',
        '2025-03-21',
      ];

      validDates.forEach(date => {
        expect(isValidMhdDate(date)).toBe(true);
      });
    });

    test('should reject dates with invalid format', () => {
      const invalidDates = [
        '2024/12/31',
        '31.12.2024',
        '12-31-2024',
        '2024-1-1',
      ];

      invalidDates.forEach(date => {
        expect(isValidMhdDate(date)).toBe(false);
      });
    });
  });

  describe('Multiple validation errors', () => {
    test('should return multiple errors for invalid product', () => {
      const product: Partial<Product> = {
        name: '',
        quantity: -5,
        unit: '',
        price: -10,
      };

      const result = validateProduct(product);
      expect(result.valid).toBe(false);
      expect(result.errors.length).toBeGreaterThan(2);
    });

    test('should identify all error fields', () => {
      const product: Partial<Product> = {
        name: '',
        quantity: -1,
        unit: '',
      };

      const result = validateProduct(product);
      const errorFields = result.errors.map(e => e.field);

      expect(errorFields).toContain('name');
      expect(errorFields).toContain('quantity');
      expect(errorFields).toContain('unit');
    });
  });
});
