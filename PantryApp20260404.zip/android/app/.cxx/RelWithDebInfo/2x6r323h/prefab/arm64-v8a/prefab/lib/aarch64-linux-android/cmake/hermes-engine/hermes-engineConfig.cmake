if(NOT TARGET hermes-engine::hermesvm)
add_library(hermes-engine::hermesvm SHARED IMPORTED)
set_target_properties(hermes-engine::hermesvm PROPERTIES
    IMPORTED_LOCATION "C:/Users/e8rdm96/.gradle/caches/8.13/transforms/6d28c529e9a41eb13be6c58196c196a8/transformed/jetified-hermes-android-250829098.0.9-release/prefab/modules/hermesvm/libs/android.arm64-v8a/libhermesvm.so"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/e8rdm96/.gradle/caches/8.13/transforms/6d28c529e9a41eb13be6c58196c196a8/transformed/jetified-hermes-android-250829098.0.9-release/prefab/modules/hermesvm/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

