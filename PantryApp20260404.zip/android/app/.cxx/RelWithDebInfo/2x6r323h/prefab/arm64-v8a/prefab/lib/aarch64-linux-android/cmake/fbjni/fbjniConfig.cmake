if(NOT TARGET fbjni::fbjni)
add_library(fbjni::fbjni SHARED IMPORTED)
set_target_properties(fbjni::fbjni PROPERTIES
    IMPORTED_LOCATION "C:/Users/e8rdm96/.gradle/caches/8.13/transforms/9b0b0b6ba9fd2cf4ec3d2f5da6568dd8/transformed/jetified-fbjni-0.7.0/prefab/modules/fbjni/libs/android.arm64-v8a/libfbjni.so"
    INTERFACE_INCLUDE_DIRECTORIES "C:/Users/e8rdm96/.gradle/caches/8.13/transforms/9b0b0b6ba9fd2cf4ec3d2f5da6568dd8/transformed/jetified-fbjni-0.7.0/prefab/modules/fbjni/include"
    INTERFACE_LINK_LIBRARIES ""
)
endif()

