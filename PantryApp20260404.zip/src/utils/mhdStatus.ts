import { differenceInDays, parseISO } from 'date-fns';

export interface MhdStatusResult {
  type: 'expired' | 'warning' | 'ok' | 'none';
  text: string;
}

/**
 * Berechnet den MHD-Status basierend auf dem MHD-Datum
 * @param mhd - Das MHD-Datum im ISO-Format (z.B. "2024-12-31")
 * @param today - Das heutige Datum (default: new Date())
 * @returns Ein Objekt mit Status-Typ und Text
 */
export function getMhdStatus(mhd: string | undefined, today: Date = new Date()): MhdStatusResult {
  if (!mhd) {
    return { type: 'none', text: 'MHD nicht angegeben' };
  }

  try {
    const mhdDate = parseISO(mhd);
    
    // Check if the parsed date is valid
    if (isNaN(mhdDate.getTime())) {
      return { type: 'none', text: 'Ungültiges Datum' };
    }
    
    const days = differenceInDays(mhdDate, today);

    if (days < 0) {
      return { type: 'expired', text: `❌ Abgelaufen am ${mhd}` };
    } else if (days <= 7) {
      return { type: 'warning', text: `⚠️ MHD bald abgelaufen! (${days} Tage)` };
    } else {
      return { type: 'ok', text: `✅ MHD: ${mhd}` };
    }
  } catch {
    return { type: 'none', text: 'Ungültiges Datum' };
  }
}
