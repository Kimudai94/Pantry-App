import { Product } from '../types/product';

/**
 * Filter and sort products based on search term and sort type
 * @param items - Array of products to filter and sort
 * @param search - Search term to filter by product name
 * @param sortType - How to sort: 'name', 'mhd', or 'price'
 * @returns Filtered and sorted array of products
 */
export function filterAndSortProducts(
  items: Product[],
  search: string,
  sortType: 'name' | 'mhd' | 'price' = 'mhd'
): Product[] {
  // Filter by search term
  let filtered = items.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );

  // Sort based on sort type
  filtered.sort((a, b) => {
    switch (sortType) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'mhd':
        if (!a.mhd) return 1;
        if (!b.mhd) return -1;
        return new Date(a.mhd).getTime() - new Date(b.mhd).getTime();
      case 'price':
        return (b.price || 0) - (a.price || 0);
      default:
        return 0;
    }
  });

  return filtered;
}

/**
 * Filter products by search term only (no sorting)
 * @param items - Array of products to filter
 * @param search - Search term to filter by product name
 * @returns Filtered array of products
 */
export function searchProducts(items: Product[], search: string): Product[] {
  return items.filter((product) =>
    product.name.toLowerCase().includes(search.toLowerCase())
  );
}

/**
 * Sort products by a given criteria
 * @param items - Array of products to sort
 * @param sortType - How to sort: 'name', 'mhd', or 'price'
 * @returns Sorted array of products
 */
export function sortProducts(
  items: Product[],
  sortType: 'name' | 'mhd' | 'price' = 'mhd'
): Product[] {
  const sorted = [...items];

  sorted.sort((a, b) => {
    switch (sortType) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'mhd':
        if (!a.mhd) return 1;
        if (!b.mhd) return -1;
        return new Date(a.mhd).getTime() - new Date(b.mhd).getTime();
      case 'price':
        return (b.price || 0) - (a.price || 0);
      default:
        return 0;
    }
  });

  return sorted;
}
