import { Product } from '../types/product';

export interface ValidationError {
  field: string;
  message: string;
}

/**
 * Validation result
 */
export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

/**
 * Validate a product object
 * @param product - Partial product to validate
 * @returns Validation result with errors if any
 */
export function validateProduct(product: Partial<Product>): ValidationResult {
  const errors: ValidationError[] = [];

  // Validate ID if provided
  if (product.id !== undefined) {
    if (!Number.isInteger(product.id) || product.id < 1) {
      errors.push({ field: 'id', message: 'Product ID must be a positive integer' });
    }
  }

  // Validate name (required)
  if (!product.name || typeof product.name !== 'string') {
    errors.push({ field: 'name', message: 'Product name is required' });
  } else if (product.name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Product name cannot be empty' });
  } else if (product.name.length > 255) {
    errors.push({ field: 'name', message: 'Product name is too long (max 255 characters)' });
  }

  // Validate quantity (required)
  if (product.quantity === undefined || product.quantity === null) {
    errors.push({ field: 'quantity', message: 'Product quantity is required' });
  } else if (typeof product.quantity !== 'number' || product.quantity < 0) {
    errors.push({ field: 'quantity', message: 'Product quantity must be a non-negative number' });
  }

  // Validate unit (required)
  if (!product.unit || typeof product.unit !== 'string') {
    errors.push({ field: 'unit', message: 'Product unit is required' });
  } else if (product.unit.trim().length === 0) {
    errors.push({ field: 'unit', message: 'Product unit cannot be empty' });
  }

  // Validate MHD (optional)
  if (product.mhd !== undefined && product.mhd !== null && product.mhd !== '') {
    if (!isValidMhdDate(product.mhd)) {
      errors.push({ field: 'mhd', message: 'MHD date must be in format YYYY-MM-DD' });
    }
  }

  // Validate price (optional)
  if (product.price !== undefined && product.price !== null) {
    if (typeof product.price !== 'number' || product.price < 0) {
      errors.push({ field: 'price', message: 'Price must be a non-negative number' });
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate MHD date format
 * @param mhd - MHD date string
 * @returns true if valid YYYY-MM-DD format
 */
export function isValidMhdDate(mhd: string): boolean {
  if (!mhd) return false;

  // Check format
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(mhd)) return false;

  // Check if it's a valid date
  const date = new Date(mhd + 'T00:00:00Z');
  if (isNaN(date.getTime())) return false;

  // Parse year, month, day and validate they match the input
  const parts = mhd.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  const day = parseInt(parts[2], 10);

  // Check if parsed dates match input (catches invalid dates like 02-30)
  if (
    date.getUTCFullYear() !== year ||
    date.getUTCMonth() + 1 !== month ||
    date.getUTCDate() !== day
  ) {
    return false;
  }

  return true;
}

/**
 * Validate product name
 * @param name - Product name
 * @returns Validation result
 */
export function validateProductName(name: string): ValidationResult {
  const errors: ValidationError[] = [];

  if (!name || typeof name !== 'string') {
    errors.push({ field: 'name', message: 'Product name is required' });
  } else if (name.trim().length === 0) {
    errors.push({ field: 'name', message: 'Product name cannot be empty' });
  } else if (name.length > 255) {
    errors.push({ field: 'name', message: 'Product name is too long (max 255 characters)' });
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate product quantity
 * @param quantity - Product quantity
 * @returns Validation result
 */
export function validateProductQuantity(quantity: string | number): ValidationResult {
  const errors: ValidationError[] = [];

  if (quantity === undefined || quantity === null || quantity === '') {
    errors.push({ field: 'quantity', message: 'Product quantity is required' });
  } else {
    const numValue = typeof quantity === 'string' ? parseFloat(quantity) : quantity;

    if (isNaN(numValue)) {
      errors.push({ field: 'quantity', message: 'Product quantity must be a number' });
    } else if (numValue < 0) {
      errors.push({ field: 'quantity', message: 'Product quantity cannot be negative' });
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate product price
 * @param price - Product price (optional)
 * @returns Validation result
 */
export function validateProductPrice(price: string | number | undefined): ValidationResult {
  const errors: ValidationError[] = [];

  if (price !== undefined && price !== null && price !== '') {
    const numValue = typeof price === 'string' ? parseFloat(price) : price;

    if (isNaN(numValue)) {
      errors.push({ field: 'price', message: 'Product price must be a number' });
    } else if (numValue < 0) {
      errors.push({ field: 'price', message: 'Product price cannot be negative' });
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
