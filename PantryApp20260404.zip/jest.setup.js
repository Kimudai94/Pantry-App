// Jest setup for React Native
jest.mock('react-native', () => {
  const RN = jest.requireActual('react-native');
  return {
    ...RN,
    Alert: {
      alert: jest.fn(),
    },
  };
});

jest.mock('@react-navigation/native', () => ({
  useFocusEffect: (callback) => {
    callback();
  },
  useNavigation: () => ({
    navigate: jest.fn(),
    goBack: jest.fn(),
  }),
}));

jest.mock('react-native-sqlite-storage', () => ({
  openDatabase: jest.fn(),
  DEBUG: jest.fn(),
  enablePromise: jest.fn(),
}));

global.console = {
  ...console,
  error: jest.fn(),
  log: jest.fn(),
  warn: jest.fn(),
};
