// Mock for database module
export const initializeDatabase = jest.fn();
export const addProduct = jest.fn();
export const updateProduct = jest.fn();
export const deleteProduct = jest.fn();
export const getAllProducts = jest.fn();
export const closeDatabase = jest.fn();
