// Mock for @testing-library/react-native to work with Node testEnvironment
module.exports = {
  render: jest.fn(() => ({
    unmount: jest.fn(),
    rerender: jest.fn(),
    toJSON: jest.fn(),
  })),
  fireEvent: {
    press: jest.fn(),
    changeText: jest.fn(),
    scroll: jest.fn(),
  },
  screen: {
    getByText: jest.fn(() => ({ onPress: jest.fn() })),
    getByPlaceholderText: jest.fn(() => ({ onChangeText: jest.fn() })),
    queryByText: jest.fn(),
    queryByPlaceholderText: jest.fn(),
    queryAllByText: jest.fn(() => []),
    queryAllByPlaceholderText: jest.fn(() => []),
    getByTestId: jest.fn(() => ({ onPress: jest.fn() })),
    debug: jest.fn(),
  },
  waitFor: jest.fn((callback) => {
    callback();
    return Promise.resolve();
  }),
};
