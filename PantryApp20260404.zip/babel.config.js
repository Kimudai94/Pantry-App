module.exports = {
  presets: [
    'module:metro-react-native-babel-preset',
    ['@babel/preset-env', { targets: { node: 'current' } }],
    '@babel/preset-react',
    '@babel/preset-typescript',
    '@babel/preset-flow',
  ],
  plugins: [],
  ignore: [
    'node_modules/@react-native/**/*.js',
  ],
};
