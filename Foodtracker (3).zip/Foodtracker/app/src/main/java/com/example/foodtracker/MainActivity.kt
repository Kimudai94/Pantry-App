package com.example.foodtracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)        
        setContent {
            AppNavGraph(
                dashboard = { onMealClick ->
                    DashboardScreen(
                        viewModel = dashboardViewModel,
                        onMealClick = onMealClick
                    )
                },
                inventory = {
                    InventoryScreen(inventoryViewModel)
                },
                meal = { mealId ->
                    MealScreen(mealViewModelFactory(mealId))
                }
            )
        }
    }
}