import androidx.lifecycle.ViewModel 
import androidx.lifecycle.viewModelScope 
import kotlinx.coroutines.flow.MutableStateFlow 
import kotlinx.coroutines.flow.StateFlow 
import kotlinx.coroutines.flow.asStateFlow 
import kotlinx.coroutines.launch

class InventoryViewModel( 
  private val loadInventory: suspend () -> List, 
  private val changeQuantity: suspend (id: Long, delta: Int) -> Unit
) : ViewModel() {
  private val _state = MutableStateFlow(InventoryUiState())
  val state: StateFlow = _state.asStateFlow()

  fun refresh() {
    viewModelScope.launch {
      _state.value = _state.value.copy(isLoading = true, error = null)
      runCatching { loadInventory() }
      .onSuccess { items -> _state.value = InventoryUiState(items = items, isLoading = false) }
      .onFailure { e -> _state.value = _state.value.copy(isLoading = false, error = e.message) }
    }
  }

  fun inc(id: Long) = update(id, +1)
  
  fun dec(id: Long) = update(id, -1)

  private fun update(id: Long, delta: Int) {
    viewModelScope.launch {
      runCatching { changeQuantity(id, delta) }.onFailure { e -> _state.value = _state.value.copy(error = e.message) }
      refresh()
    }
  }
}
