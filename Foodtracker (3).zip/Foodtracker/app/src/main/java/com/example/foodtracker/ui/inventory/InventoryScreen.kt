package com.example.foodtracker.ui.inventory

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun InventoryScreen(viewModel: InventoryViewModel) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(Unit) { viewModel.refresh() }

    when {
        state.isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        state.error != null -> Text("Fehler: ${state.error}")
        else -> InventoryContent(state, viewModel)
    }
}

@Composable
private fun InventoryContent(state: InventoryUiState, viewModel: InventoryViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(state.items) { item ->
            Card(Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(item.name, style = MaterialTheme.typography.titleMedium)
                        Text("Menge: ${item.quantity} ${item.unit}")
                        item.expiresAt?.let { Text("Ablauf: $it") }
                    }
                    Row {
                        IconButton(onClick = { viewModel.dec(item.id) }) { Text("–") }
                        IconButton(onClick = { viewModel.inc(item.id) }) { Text("+") }
                    }
                }
            }
        }
    }
}
