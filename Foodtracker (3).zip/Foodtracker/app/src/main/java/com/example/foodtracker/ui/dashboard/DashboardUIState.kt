import com.example.foodtracker.domain.model.MealStatus

data class DashboardUiState(
    val nowEating: List = emptyList(), 
    val thisWeek: List = emptyList(), 
    val freezerReserve: List = emptyList(), 
    val isLoading: Boolean = true,
    val error: String? = null
)

data class DashboardMealItem(
    val mealId: Long, 
    val name: String, 
    val remainingPortions: Int, 
    val expiresInDays: Long, 
    val status: MealStatus
)
