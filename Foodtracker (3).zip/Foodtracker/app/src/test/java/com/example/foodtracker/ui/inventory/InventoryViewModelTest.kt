@OptIn(ExperimentalCoroutinesApi::class)
class InventoryViewModelTest {

    @Test
    fun refresh_loads_items_and_sets_state() = runTest {
        val items = listOf(
            InventoryItemUi(
                id = 1,
                name = "Protein Pudding",
                quantity = 3,
                unit = "Stück",
                expiresAt = null
            )
        )

        val vm = InventoryViewModel(
            loadInventory = { items },
            changeQuantity = { _, _ -> }
        )

        vm.refresh()

        val state = vm.state.value
        assertFalse(state.isLoading)
        assertEquals(1, state.items.size)
        assertEquals("Protein Pudding", state.items.first().name)
    }
}