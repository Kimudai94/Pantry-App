@get:Rule
val composeRule = createComposeRule()

@Test
fun startDestination_is_dashboard() {
    composeRule.setContent {
        AppNavGraph(
            dashboard = {},
            inventory = {},
            meal = {}
        )
    }
    // Smoke test: if it renders, navigation works
}