@OptIn(ExperimentalCoroutinesApi::class)
class MealRepositoryTest {

    private lateinit var db: AppDatabase
    private lateinit var repo: MealRepository

    @BeforeEach
    fun setup() {
        db = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            AppDatabase::class.java
        ).allowMainThreadQueries().build()

        repo = MealRepository(db.mealDao(), db.mealEventDao())
    }

    @AfterEach
    fun tearDown() {
        db.close()
    }

    @Test
    fun consuming_event_reduces_remaining_portions() = runTest {
        val meal = Meal(
            id = 0,
            name = "Curry",
            prepDate = LocalDate.now(),
            storage = StorageLocation.FRIDGE,
            totalPortions = 3,
            shelfLifeDays = 4
        )

        repo.save(meal)
        val saved = repo.loadAll().first()

        repo.consumePortion(saved.id)

        val updated = repo.loadById(saved.id)
        assertEquals(2, updated.totalPortions)
    }
}