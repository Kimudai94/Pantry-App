import com.example.foodtracker.domain.model.Meal 
import com.example.foodtracker.domain.model.StorageLocation 
import com.example.foodtracker.domain.usecase.ComputeMealStatus 
import kotlinx.coroutines.ExperimentalCoroutinesApi 
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest 
import org.junit.jupiter.api.Assertions.* 
import org.junit.jupiter.api.Test 
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {
    
    private class FakeMealRepo(initial: List<Meal>) {
        private val _meals = MutableStateFlow(initial)
        fun observeAll(): StateFlow<List<Meal>> = _meals
        fun emit(meals: List<Meal>) { _meals.value = meals }
    }

    @Test
    fun `state becomes non-loading when repo emits`() = runTest {
        val repo = FakeMealRepo(emptyList())

        val vm = DashboardViewModel(
            repo = object : com.example.foodtracker.data.repository.MealRepository /* oder Interface */ {
                // Wenn du kein Interface hast: nimm eine kleine Wrapper-Factory oder passe den VM-Konstruktor auf (Flow<List<Meal>>) an.
            },
            computeMealStatus = ComputeMealStatus()
        )

        val job = backgroundScope.launch { vm.state.collect{} }

        repo.emit(
            listOf(
                Meal(
                    id = 1L,
                    name = "Curry",
                    prepDate = LocalDate.now(),
                    storage = StorageLocation.FRIDGE,
                    totalPortions = 2,
                    shelfLifeDays = 4
                )
            )
        )

        advanceUntilIdle()

        val state = vm.state.value
        assertFalse(state.isLoading)
        assertNotNull(state)
        job.cancel()
    }
}
