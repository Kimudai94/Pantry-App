import com.example.foodtracker.domain.model.Meal
import com.example.foodtracker.domain.model.StorageLocation
import com.example.foodtracker.domain.usecase.ComputeMealStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class MealViewModelTest {

    private class FakeMealRepo(initialMeal: Meal) {
        val mealFlow = MutableStateFlow(initialMeal)
        var consumeCalls = 0

        fun observeById(id: Long) = mealFlow
        suspend fun consumePortion(mealId: Long) {
            consumeCalls++
            mealFlow.value = mealFlow.value.copy(totalPortions = mealFlow.value.totalPortions - 1)
        }
    }

    @Test
    fun `eatOnePortion triggers repo and state updates`() = runTest {
        val initial = Meal(
            id = 1L,
            name = "Pasta",
            prepDate = LocalDate.now(),
            storage = StorageLocation.FRIDGE,
            totalPortions = 2,
            shelfLifeDays = 4
        )
        val repo = FakeMealRepo(initial)

        val vm = MealViewModel(
            mealId = 1L,
            repo = object : com.example.foodtracker.data.repository.MealRepository /* oder Interface */ {
                // analog: besser ein Interface oder Flow-Injection nutzen
            },
            computeMealStatus = ComputeMealStatus()
        )

        val job = backgroundScope.launch { vm.state.collect { } }

        advanceUntilIdle()
        assertFalse(vm.state.value.isLoading)

        vm.eatOnePortion()
        advanceUntilIdle()

        assertEquals(1, repo.consumeCalls)
        assertEquals(1, vm.state.value.remainingPortions) // oder totalPortions/remainingPortions je nach Mapping
        job.cancel()
    }
}