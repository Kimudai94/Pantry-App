
import com.example.foodtracker.domain.model.Meal
import com.example.foodtracker.domain.model.StorageLocation
import com.example.foodtracker.domain.usecase.ComputeMealStatus
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Test
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class MealViewModelTest {

    @Test
    fun `eatOnePortion triggers onEat and state updates via injected mealFlow`() = runTest {
        val fixedToday = LocalDate.of(2026, 4, 8)

        // given: Meal-Flow wird injiziert
        val mealFlow = MutableStateFlow(
            Meal(
                id = 1L,
                name = "Pasta",
                prepDate = fixedToday.minusDays(1),
                storage = StorageLocation.FRIDGE,
                totalPortions = 2,
                shelfLifeDays = 4
            )
        )

        var eatCalls = 0

        // onEatOnePortion simuliert „Event schreiben“ + DB/Repo emittiert neues Meal
        val onEatOnePortion: suspend () -> Unit = {
            eatCalls++
            mealFlow.value = mealFlow.value.copy(totalPortions = mealFlow.value.totalPortions - 1)
        }

        val vm = MealViewModel(
            mealFlow = mealFlow,
            onEatOnePortion = onEatOnePortion,
            computeMealStatus = ComputeMealStatus(),
            today = { fixedToday }
        )

        // WhileSubscribed startet erst bei Subscriber
        val job = backgroundScope.launch { vm.state.collect { /* no-op */ } }
        advanceUntilIdle()

        // initial
        assertFalse(vm.state.value.isLoading)
        assertEquals(2, vm.state.value.remainingPortions)

        // when
        vm.eatOnePortion()
        advanceUntilIdle()

        // then
        assertEquals(1, eatCalls)
        assertEquals(1, vm.state.value.remainingPortions)

        job.cancel()
    }
}
