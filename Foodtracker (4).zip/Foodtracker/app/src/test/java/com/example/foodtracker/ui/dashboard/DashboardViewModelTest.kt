import com.example.foodtracker.domain.model.Meal 
import com.example.foodtracker.domain.model.StorageLocation 
import com.example.foodtracker.domain.usecase.ComputeMealStatus 
import kotlinx.coroutines.ExperimentalCoroutinesApi 
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest 
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test 
import java.time.LocalDate

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {
    @Test
    fun `state becomes non-loading when mealsFlow emits`() = runTest {
        val mealsFlow = MutableStateFlow(emptyList<Meal>())
        val fixedToday = LocalDate.of(2026, 4, 8)
        val vm = DashboardViewModel(
            mealsFlow = mealsFlow,
            computeMealStatus = ComputeMealStatus(),
            today = { fixedToday }
        )
        val job = backgroundScope.launch { vm.state.collect { /* no-op */ } }
        mealsFlow.value = listOf(
            Meal(
                id = 1L,
                name = "Curry",
                prepDate = fixedToday.minusDays(1),
                storage = StorageLocation.FRIDGE,
                totalPortions = 2,
                shelfLifeDays = 4
            )
        )
        advanceUntilIdle()

        val state = vm.state.value
        assertFalse(state.isLoading)
        assertTrue(state.nowEating.isNotEmpty() || state.thisWeek.isNotEmpty() || state.freezerReserve.isNotEmpty())

        job.cancel()
    }
}

