package com.example.foodtracker.ui.inventory

import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.advanceUntilIdle
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test

@OptIn(ExperimentalCoroutinesApi::class)
class InventoryViewModelTest {

    @Test
    fun `write error is surfaced as event and state error`() = runTest {
        val itemsFlow = MutableStateFlow(
            listOf(InventoryItemUi(id = 1, name = "Milch", quantity = 1, unit = "L", expiresAt = null))
        )

        val vm = InventoryViewModel(
            inventoryFlow = itemsFlow,
            changeQuantity = { _, _ -> throw IllegalStateException("DB down") }
        )

        // Collector starten (WhileSubscribed)
        val stateJob = backgroundScope.launch { vm.state.collect { } }

        // Event Collector vorbereiten
        val eventDeferred = async { vm.events.first() }

        vm.inc(1)
        advanceUntilIdle()

        val ev = eventDeferred.await()
        assertTrue(ev is InventoryEvent.ShowError)
        assertEquals("DB down", (ev as InventoryEvent.ShowError).message)

        assertEquals("DB down", vm.state.value.error)

        stateJob.cancel()
    }

    @Test
    fun `undo emits when change succeeds and undo reverts delta`() = runTest {
        val itemsFlow = MutableStateFlow(
            listOf(InventoryItemUi(id = 1, name = "Reis", quantity = 2, unit = "kg", expiresAt = null))
        )

        var qty = 2
        val vm = InventoryViewModel(
            inventoryFlow = itemsFlow,
            changeQuantity = { id, delta ->
                if (id != 1L) error("wrong id")
                qty = (qty + delta).coerceAtLeast(0)
                // Simuliere "DB update" -> Flow emittiert neu:
                itemsFlow.value = listOf(itemsFlow.value.first().copy(quantity = qty))
            }
        )

        val stateJob = backgroundScope.launch { vm.state.collect { } }

        // inc -> sollte Undo anbieten
        val undoEventDeferred = async { vm.events.first() }
        vm.inc(1)
        advanceUntilIdle()

        val undoEv = undoEventDeferred.await()
        assertTrue(undoEv is InventoryEvent.ShowUndo)
        assertEquals(3, vm.state.value.items.first().quantity)

        // undo call
        vm.undo(id = 1, deltaApplied = (undoEv as InventoryEvent.ShowUndo).deltaApplied)
        advanceUntilIdle()

        assertEquals(2, vm.state.value.items.first().quantity)

        stateJob.cancel()
    }
}